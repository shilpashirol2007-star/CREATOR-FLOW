import React, { useState } from 'react';
import { AuthProvider, useAuth } from './context/AuthContext';
import { AuthPage } from './pages/AuthPage';
import { OnboardingPage } from './pages/OnboardingPage';
import { DashboardPage } from './pages/DashboardPage';
import { ProfilePage } from './pages/ProfilePage';
import { ContentPage } from './pages/ContentPage';
import { CollaborationsPage } from './pages/CollaborationsPage';
import { PartnershipsPage } from './pages/PartnershipsPage';
import { CalendarPage } from './pages/CalendarPage';
import { AnalyticsPage } from './pages/AnalyticsPage';
import { FinancePage } from './pages/FinancePage';
import { NotificationsPage } from './pages/NotificationsPage';
import { SettingsPage } from './pages/SettingsPage';
import { Navbar } from './components/Navbar';
import { Sidebar } from './components/Sidebar';
import { Menu } from 'lucide-react';

function MainApp() {
  const { user, loading } = useAuth();
  const [currentTab, setCurrentTab] = useState<string>('dashboard');
  const [mobileMenuOpen, setMobileMenuOpen] = useState<boolean>(false);

  if (loading) {
    return (
      <div className="min-h-screen bg-slate-50 dark:bg-slate-950 flex flex-col items-center justify-center">
        <div className="w-10 h-10 rounded-xl bg-indigo-600 text-white flex items-center justify-center font-bold text-lg animate-pulse mb-3">
          CF
        </div>
        <div className="text-xs font-semibold text-slate-500">Connecting to CreatorFlow engine...</div>
      </div>
    );
  }

  // 1. Not Authenticated
  if (!user) {
    return <AuthPage />;
  }

  // 2. Authenticated but Needs Onboarding
  if (!user.onboarded) {
    return <OnboardingPage onComplete={() => setCurrentTab('dashboard')} />;
  }

  // 3. Fully Authenticated & Onboarded Workspace
  const renderDepartment = () => {
    switch (currentTab) {
      case 'dashboard':
        return <DashboardPage onNavigate={setCurrentTab} />;
      case 'profile':
        return <ProfilePage />;
      case 'content':
        return <ContentPage />;
      case 'collaborations':
        return <CollaborationsPage />;
      case 'partnerships':
        return <PartnershipsPage onNavigate={setCurrentTab} />;
      case 'calendar':
        return <CalendarPage />;
      case 'analytics':
        return <AnalyticsPage />;
      case 'finance':
        return <FinancePage />;
      case 'notifications':
        return <NotificationsPage onNavigate={setCurrentTab} />;
      case 'settings':
        return <SettingsPage />;
      default:
        return <DashboardPage onNavigate={setCurrentTab} />;
    }
  };

  const getPrimaryAction = () => {
    if (currentTab === 'content') {
      return {
        label: '+ New Post',
        onClick: () => {
          // Triggers modal in content page
          const btn = Array.from(document.querySelectorAll('button')).find((item) => item.title.includes('New Content Item') || item.textContent?.includes('New Content Item')) as HTMLButtonElement | undefined;
          btn?.click();
        }
      };
    }
    if (currentTab === 'calendar') {
      return {
        label: '+ Add Milestone',
        onClick: () => {
          const btn = Array.from(document.querySelectorAll('button')).find((item) => item.textContent?.includes('Add Schedule Entry')) as HTMLButtonElement | undefined;
          btn?.click();
        }
      };
    }
    if (currentTab === 'collaborations') {
      return {
        label: user.role === 'creator' ? 'Browse Campaigns' : 'Find Creators',
        onClick: () => setCurrentTab('partnerships')
      };
    }
    if (currentTab === 'analytics') {
      return {
        label: '+ Connect Channel',
        onClick: () => {
          const btn = Array.from(document.querySelectorAll('button')).find((item) => item.textContent?.includes('Connect Channel')) as HTMLButtonElement | undefined;
          btn?.click();
        }
      };
    }
    return undefined;
  };

  return (
    <div className="min-h-screen bg-slate-50 dark:bg-slate-950 flex text-slate-900 dark:text-slate-100 antialiased selection:bg-indigo-500 selection:text-white">
      {/* Sidebar Navigation */}
      <Sidebar
        currentTab={currentTab}
        onNavigate={setCurrentTab}
        isOpenMobile={mobileMenuOpen}
        onCloseMobile={() => setMobileMenuOpen(false)}
      />

      {/* Main Workspace Frame */}
      <div className="flex-1 lg:pl-64 flex flex-col min-w-0">
        {/* Mobile top trigger */}
        <div className="lg:hidden h-14 px-4 bg-white dark:bg-slate-900 border-b border-slate-200 dark:border-slate-800 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <button
              onClick={() => setMobileMenuOpen(true)}
              className="p-1.5 text-slate-600 dark:text-slate-300 rounded hover:bg-slate-100 dark:hover:bg-slate-800"
              aria-label="Open navigation menu"
            >
              <Menu className="w-5 h-5" />
            </button>
            <span className="font-bold text-sm text-slate-900 dark:text-white">CreatorFlow</span>
          </div>
          <span className="text-[11px] font-semibold text-indigo-600 capitalize bg-indigo-50 dark:bg-indigo-950/60 px-2 py-0.5 rounded">
            {user.role}
          </span>
        </div>

        {/* Top Bar */}
        <Navbar
          currentTab={currentTab}
          onNavigate={setCurrentTab}
          primaryAction={getPrimaryAction()}
        />

        {/* Department Viewport */}
        <main className="flex-1 overflow-y-auto">
          {renderDepartment()}
        </main>
      </div>
    </div>
  );
}

export default function App() {
  return (
    <AuthProvider>
      <MainApp />
    </AuthProvider>
  );
}
