import React, { createContext, useContext, useState, useEffect } from 'react';
import { User, CreatorProfile, BrandProfile, SocialAccount } from '../types';
import { api } from '../lib/api';

interface AuthContextType {
  user: User | null;
  creatorProfile: CreatorProfile | null;
  brandProfile: BrandProfile | null;
  socialAccounts: SocialAccount[];
  loading: boolean;
  login: (email: string, password: string) => Promise<void>;
  signup: (email: string, password: string, fullName: string, role: 'creator' | 'brand') => Promise<void>;
  loginGoogle: (email: string, fullName: string, avatarUrl?: string, role?: 'creator' | 'brand') => Promise<void>;
  logout: () => void;
  refreshUser: () => Promise<void>;
  switchRole: (role: 'creator' | 'brand') => Promise<void>;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export const AuthProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [user, setUser] = useState<User | null>(null);
  const [creatorProfile, setCreatorProfile] = useState<CreatorProfile | null>(null);
  const [brandProfile, setBrandProfile] = useState<BrandProfile | null>(null);
  const [socialAccounts, setSocialAccounts] = useState<SocialAccount[]>([]);
  const [loading, setLoading] = useState<boolean>(true);

  const fetchSession = async () => {
    const token = localStorage.getItem('creatorflow_token');
    if (!token) {
      setUser(null);
      setLoading(false);
      return;
    }

    try {
      const data = await api.getMe();
      setUser(data.user);
      setCreatorProfile(data.creatorProfile);
      setBrandProfile(data.brandProfile);
      setSocialAccounts(data.socialAccounts);
    } catch (err) {
      console.warn('Failed to restore session:', err);
      localStorage.removeItem('creatorflow_token');
      setUser(null);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchSession();
  }, []);

  const login = async (email: string, password: string) => {
    const res = await api.login({ email, password });
    localStorage.setItem('creatorflow_token', res.token);
    await fetchSession();
  };

  const signup = async (email: string, password: string, fullName: string, role: 'creator' | 'brand') => {
    const res = await api.signup({ email, password, fullName, role });
    localStorage.setItem('creatorflow_token', res.token);
    await fetchSession();
  };

  const loginGoogle = async (email: string, fullName: string, avatarUrl?: string, role: 'creator' | 'brand' = 'creator') => {
    const res = await api.loginGoogle({ email, fullName, avatarUrl, role });
    localStorage.setItem('creatorflow_token', res.token);
    await fetchSession();
  };

  const logout = () => {
    localStorage.removeItem('creatorflow_token');
    setUser(null);
    setCreatorProfile(null);
    setBrandProfile(null);
    setSocialAccounts([]);
  };

  const refreshUser = async () => {
    await fetchSession();
  };

  const switchRole = async (newRole: 'creator' | 'brand') => {
    await api.switchRole(newRole);
    await fetchSession();
  };

  return (
    <AuthContext.Provider
      value={{
        user,
        creatorProfile,
        brandProfile,
        socialAccounts,
        loading,
        login,
        signup,
        loginGoogle,
        logout,
        refreshUser,
        switchRole
      }}
    >
      {children}
    </AuthContext.Provider>
  );
};

export const useAuth = () => {
  const context = useContext(AuthContext);
  if (!context) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
};
