export type UserRole = 'creator' | 'brand';

export interface User {
  id: string;
  email: string;
  role: UserRole;
  fullName: string;
  avatarUrl?: string;
  phone?: string;
  onboarded: boolean;
  createdAt: string;
  updatedAt: string;
}

export interface CreatorProfile {
  id: string;
  userId: string;
  bio: string;
  niche: string;
  location: string;
  website?: string;
  primaryPlatform: 'youtube' | 'instagram' | 'tiktok' | 'twitter' | 'other';
  contentCategories: string[];
  ratePost?: number;
  rateVideo?: number;
  rateReel?: number;
  rateStory?: number;
  acceptGifted: boolean;
  acceptRevShare: boolean;
  mediaKitUrl?: string;
  createdAt: string;
  updatedAt: string;
}

export interface BrandProfile {
  id: string;
  userId: string;
  companyName: string;
  industry: string;
  website?: string;
  logoUrl?: string;
  contactPerson: string;
  budgetTier?: string;
  description: string;
  targetAudience?: string;
  createdAt: string;
  updatedAt: string;
}

export interface SocialAccount {
  id: string;
  userId: string;
  platform: 'youtube' | 'instagram' | 'tiktok' | 'twitter';
  handle: string;
  displayName: string;
  profileImage?: string;
  followerCount: number;
  subscribers?: number;
  totalViews?: number;
  engagementRate?: number;
  isVerifiedApi: boolean;
  apiStatus: 'connected' | 'manual' | 'unconnected';
  lastSyncedAt?: string;
}

export type PostStatus = 'idea' | 'scripting' | 'in_review' | 'scheduled' | 'published';
export type ContentType = 'video' | 'reel' | 'short' | 'post' | 'story' | 'carousel';

export interface ContentPost {
  id: string;
  userId: string;
  title: string;
  platform: 'youtube' | 'instagram' | 'tiktok' | 'twitter';
  contentType: ContentType;
  status: PostStatus;
  scheduledFor?: string;
  publishedAt?: string;
  postUrl?: string;
  caption?: string;
  deliverablesNotes?: string;
  campaignId?: string;
  views: number;
  likes: number;
  comments: number;
  shares: number;
  createdAt: string;
  updatedAt: string;
}

export interface Campaign {
  id: string;
  brandId: string;
  brandName?: string;
  brandLogo?: string;
  title: string;
  description: string;
  budget: number;
  compensationType: 'fixed' | 'rev_share' | 'gifted' | 'hybrid';
  category: string;
  requirements: string;
  deadline: string;
  status: 'draft' | 'active' | 'in_progress' | 'completed' | 'paused';
  createdAt: string;
  updatedAt: string;
}

export interface DeliverableItem {
  id: string;
  title: string;
  platform: 'youtube' | 'instagram' | 'tiktok' | 'twitter';
  type: ContentType;
  status: 'pending' | 'submitted' | 'approved' | 'published';
  proofUrl?: string;
  dueDate: string;
}

export type CollabStatus =
  | 'requested'
  | 'negotiating'
  | 'accepted'
  | 'rejected'
  | 'in_progress'
  | 'completed'
  | 'cancelled';

export interface Collaboration {
  id: string;
  campaignId?: string;
  campaignTitle?: string;
  brandId: string;
  brandName: string;
  brandLogo?: string;
  creatorId: string;
  creatorName: string;
  creatorAvatar?: string;
  creatorNiche?: string;
  status: CollabStatus;
  offeredAmount: number;
  agreedAmount: number;
  terms: string;
  deliverables: DeliverableItem[];
  creatorNotes?: string;
  brandNotes?: string;
  paymentStatus: 'unpaid' | 'in_escrow' | 'released' | 'refunded';
  createdAt: string;
  updatedAt: string;
}

export interface CalendarEvent {
  id: string;
  userId: string;
  title: string;
  description?: string;
  eventType: 'post_publish' | 'deliverable_deadline' | 'brand_meeting' | 'campaign_launch';
  date: string;
  endDate?: string;
  allDay: boolean;
  relatedId?: string;
  status?: string;
  createdAt: string;
}

export interface AnalyticsRecord {
  id: string;
  userId: string;
  platform: 'youtube' | 'instagram' | 'tiktok' | 'twitter';
  recordedDate: string;
  followers: number;
  impressions: number;
  reach: number;
  views: number;
  engagementRate: number;
  shares: number;
  comments: number;
  source: 'api' | 'manual';
}

export interface Payment {
  id: string;
  collaborationId?: string;
  campaignTitle?: string;
  creatorId: string;
  creatorName?: string;
  brandId: string;
  brandName?: string;
  amount: number;
  currency: string;
  status: 'pending' | 'in_escrow' | 'released' | 'failed';
  invoiceNumber: string;
  paymentMethod: string;
  transactionDate: string;
  notes?: string;
  createdAt: string;
}

export interface Notification {
  id: string;
  userId: string;
  title: string;
  message: string;
  type: 'collab_offer' | 'status_update' | 'payment' | 'deadline' | 'system';
  read: boolean;
  link?: string;
  createdAt: string;
}

export interface SupabaseConfigStatus {
  configured: boolean;
  urlConfigured: boolean;
  keyConfigured: boolean;
  serviceRoleConfigured: boolean;
  connected: boolean;
  provider: 'supabase' | 'local_persistent';
  tablesReady?: boolean;
  message: string;
}
