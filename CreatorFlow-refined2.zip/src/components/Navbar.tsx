import React, { useState, useEffect } from 'react';
import { Bell, Database, CheckCircle, AlertCircle, Sparkles } from 'lucide-react';
import { useAuth } from '../context/AuthContext';
import { api } from '../lib/api';

interface NavbarProps {
  currentTab: string;
  onNavigate: (tab: string) => void;
  primaryAction?: {
    label: string;
    onClick: () => void;
  };
}

export const Navbar: React.FC<NavbarProps> = ({ currentTab, onNavigate, primaryAction }) => {
  const { user } = useAuth();
  const [supabaseStatus, setSupabaseStatus] = useState<any>(null);
  const [unreadCount, setUnreadCount] = useState<number>(0);

  useEffect(() => {
    const fetchStatus = async () => {
      try {
        const status = await api.getSupabaseStatus();
        setSupabaseStatus(status);
        const notifications = await api.getNotifications();
        setUnreadCount(notifications.filter((n: any) => !n.read).length);
      } catch (err) {
        // quiet fallback
      }
    };
    fetchStatus();
    const interval = setInterval(fetchStatus, 30000);
    return () => clearInterval(interval);
  }, []);

  const getBreadcrumb = () => {
    switch (currentTab) {
      case 'dashboard': return 'Overview';
      case 'profile': return user?.role === 'brand' ? 'Brand Profile' : 'Creator Profile & Media Kit';
      case 'content': return 'Content Management';
      case 'campaigns': return 'Campaign Management';
      case 'collaborations': return 'Brand Collaborations';
      case 'partnerships': return user?.role === 'brand' ? 'Discover Creators' : 'Brand Opportunities';
      case 'calendar': return 'Calendar & Scheduling';
      case 'analytics': return 'Social Media Analytics';
      case 'finance': return 'Finance & Earnings';
      case 'notifications': return 'Notifications';
      case 'settings': return 'Settings & Supabase';
      default: return 'Overview';
    }
  };

  return (
    <header className="h-16 px-6 border-b border-slate-200 dark:border-slate-800 bg-white/80 dark:bg-slate-900/80 backdrop-blur-md flex items-center justify-between gap-6 sticky top-0 z-30">
      {/* Zone 1: Breadcrumb */}
      <div className="flex items-center gap-2 text-sm text-slate-500 dark:text-slate-400">
        <span className="font-semibold text-slate-900 dark:text-white">CreatorFlow</span>
        <span aria-hidden="true" className="text-slate-300 dark:text-slate-700">/</span>
        <span className="text-slate-700 dark:text-slate-200 font-medium">{getBreadcrumb()}</span>
      </div>

      {/* Zone 2: Supabase connection indicator */}
      <div className="flex items-center gap-3">
        <button
          onClick={() => onNavigate('settings')}
          className={`flex items-center gap-1.5 px-2.5 py-1 text-xs rounded-md transition-colors border ${
            supabaseStatus?.connected
              ? 'bg-emerald-50 text-emerald-700 border-emerald-200 dark:bg-emerald-950/40 dark:text-emerald-300 dark:border-emerald-800'
              : 'bg-slate-100 text-slate-700 border-slate-200 hover:bg-slate-200 dark:bg-slate-800 dark:text-slate-300 dark:border-slate-700'
          }`}
          title="Click to view Supabase database configuration in Settings"
        >
          <Database className="w-3.5 h-3.5" />
          <span className="hidden sm:inline font-mono">
            {supabaseStatus?.connected ? 'Supabase Live' : 'Persistent DB (Ready)'}
          </span>
          {supabaseStatus?.connected ? (
            <CheckCircle className="w-3 h-3 text-emerald-600" />
          ) : (
            <span className="w-1.5 h-1.5 rounded-full bg-slate-400" />
          )}
        </button>

        {/* Notifications Button */}
        <button
          onClick={() => onNavigate('notifications')}
          className="relative p-2 text-slate-600 dark:text-slate-300 hover:text-slate-900 dark:hover:text-white hover:bg-slate-100 dark:hover:bg-slate-800 rounded-lg transition-colors"
          aria-label="View Notifications"
        >
          <Bell className="w-4 h-4" />
          {unreadCount > 0 && (
            <span className="absolute top-1 right-1 w-4 h-4 text-[10px] font-bold bg-indigo-600 text-white flex items-center justify-center rounded-full">
              {unreadCount > 9 ? '9+' : unreadCount}
            </span>
          )}
        </button>

        {/* Zone 3: Primary Action Button */}
        {primaryAction && (
          <button
            onClick={primaryAction.onClick}
            className="px-3.5 py-1.5 text-xs font-semibold text-white bg-slate-900 dark:bg-indigo-600 hover:bg-slate-800 dark:hover:bg-indigo-500 rounded-lg transition-colors whitespace-nowrap shadow-sm flex items-center gap-1.5"
          >
            <span>{primaryAction.label}</span>
          </button>
        )}
      </div>
    </header>
  );
};
