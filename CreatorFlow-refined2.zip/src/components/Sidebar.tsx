import React from 'react';
import {
  LayoutDashboard,
  User as UserIcon,
  Video,
  Briefcase,
  Users,
  Calendar,
  BarChart3,
  DollarSign,
  Bell,
  Settings,
  LogOut,
  Building2,
  Sparkles,
  ArrowRightLeft
} from 'lucide-react';
import { useAuth } from '../context/AuthContext';

interface SidebarProps {
  currentTab: string;
  onNavigate: (tab: string) => void;
  isOpenMobile?: boolean;
  onCloseMobile?: () => void;
}

export const Sidebar: React.FC<SidebarProps> = ({
  currentTab,
  onNavigate,
  isOpenMobile,
  onCloseMobile
}) => {
  const { user, logout, switchRole } = useAuth();
  const isCreator = user?.role === 'creator';

  const navItems = [
    { id: 'dashboard', label: 'Dashboard', icon: LayoutDashboard },
    { id: 'profile', label: isCreator ? 'Creator Profile' : 'Brand Profile', icon: isCreator ? UserIcon : Building2 },
    { id: 'content', label: isCreator ? 'Content Management' : 'Campaigns', icon: Video },
    { id: 'collaborations', label: 'Brand Collaborations', icon: Briefcase },
    { id: 'partnerships', label: isCreator ? 'Opportunities' : 'Discover Creators', icon: Users },
    { id: 'calendar', label: 'Calendar & Schedule', icon: Calendar },
    { id: 'analytics', label: 'Social Analytics', icon: BarChart3 },
    { id: 'finance', label: 'Finance & Earnings', icon: DollarSign },
    { id: 'notifications', label: 'Notifications', icon: Bell },
    { id: 'settings', label: 'Settings & Supabase', icon: Settings },
  ];

  const handleRoleToggle = async () => {
    const nextRole = isCreator ? 'brand' : 'creator';
    await switchRole(nextRole);
  };

  return (
    <>
      {/* Mobile Backdrop */}
      {isOpenMobile && (
        <div
          onClick={onCloseMobile}
          className="fixed inset-0 bg-slate-900/50 backdrop-blur-xs z-40 lg:hidden"
        />
      )}

      <aside
        className={`fixed top-0 bottom-0 left-0 w-64 bg-white dark:bg-slate-900 border-r border-slate-200 dark:border-slate-800 flex flex-col z-50 transition-transform duration-200 lg:translate-x-0 ${
          isOpenMobile ? 'translate-x-0' : '-translate-x-full'
        }`}
      >
        {/* Brand Header */}
        <div className="h-16 px-6 border-b border-slate-200 dark:border-slate-800 flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-lg bg-indigo-600 text-white flex items-center justify-center font-bold text-sm tracking-tight shadow-xs">
              CF
            </div>
            <div>
              <div className="font-bold text-slate-900 dark:text-white leading-tight">CreatorFlow</div>
              <div className="text-[11px] text-slate-500 font-medium">SaaS Platform</div>
            </div>
          </div>
        </div>

        {/* Role Switcher Pill */}
        <div className="px-4 pt-4 pb-2">
          <div className="p-1.5 bg-slate-100 dark:bg-slate-800/80 rounded-lg flex items-center justify-between">
            <div className="flex items-center gap-2 pl-1.5">
              <span className="text-xs font-semibold text-slate-700 dark:text-slate-300">
                Mode: <span className="text-indigo-600 dark:text-indigo-400 capitalize">{user?.role}</span>
              </span>
            </div>
            <button
              onClick={handleRoleToggle}
              title="Quickly switch between Creator and Brand perspective"
              className="px-2 py-1 text-[11px] font-medium bg-white dark:bg-slate-700 text-slate-700 dark:text-slate-200 rounded shadow-xs hover:bg-slate-50 dark:hover:bg-slate-600 transition-colors flex items-center gap-1"
            >
              <ArrowRightLeft className="w-3 h-3 text-indigo-500" />
              <span>Switch</span>
            </button>
          </div>
        </div>

        {/* Navigation list */}
        <nav className="flex-1 px-3 py-2 space-y-1 overflow-y-auto">
          {navItems.map(item => {
            const Icon = item.icon;
            const active = currentTab === item.id;
            return (
              <button
                key={item.id}
                onClick={() => {
                  onNavigate(item.id);
                  onCloseMobile?.();
                }}
                className={`w-full flex items-center gap-3 px-3 py-2 text-xs font-medium rounded-lg transition-colors text-left ${
                  active
                    ? 'bg-indigo-50 dark:bg-indigo-950/40 text-indigo-700 dark:text-indigo-300 font-semibold'
                    : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-slate-100 hover:bg-slate-100/70 dark:hover:bg-slate-800/50'
                }`}
              >
                <Icon className={`w-4 h-4 shrink-0 ${active ? 'text-indigo-600 dark:text-indigo-400' : 'text-slate-400'}`} />
                <span className="truncate">{item.label}</span>
              </button>
            );
          })}
        </nav>

        {/* User Card & Logout */}
        <div className="p-3 border-t border-slate-200 dark:border-slate-800 bg-slate-50/50 dark:bg-slate-900/50">
          <div className="flex items-center justify-between gap-2 p-2 rounded-lg bg-white dark:bg-slate-800/80 border border-slate-200 dark:border-slate-700/60 shadow-xs">
            <div className="flex items-center gap-2.5 min-w-0">
              {user?.avatarUrl ? (
                <img
                  src={user.avatarUrl}
                  alt={user.fullName}
                  referrerPolicy="no-referrer"
                  className="w-8 h-8 rounded-full object-cover shrink-0 border border-slate-200"
                />
              ) : (
                <div className="w-8 h-8 rounded-full bg-slate-200 dark:bg-slate-700 text-slate-700 dark:text-slate-300 flex items-center justify-center font-bold text-xs shrink-0">
                  {user?.fullName?.charAt(0) || 'U'}
                </div>
              )}
              <div className="min-w-0 flex-1">
                <div className="text-xs font-semibold text-slate-900 dark:text-white truncate">
                  {user?.fullName || 'User'}
                </div>
                <div className="text-[11px] text-slate-500 truncate">
                  {user?.email}
                </div>
              </div>
            </div>

            <button
              onClick={logout}
              title="Sign Out"
              className="p-1.5 text-slate-400 hover:text-rose-600 dark:hover:text-rose-400 hover:bg-slate-100 dark:hover:bg-slate-700 rounded transition-colors shrink-0"
              aria-label="Log out"
            >
              <LogOut className="w-4 h-4" />
            </button>
          </div>
        </div>
      </aside>
    </>
  );
};
