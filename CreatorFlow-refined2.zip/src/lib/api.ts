const API_BASE = '/api';

function getAuthToken(): string | null {
  return localStorage.getItem('creatorflow_token');
}

export async function apiFetch<T>(endpoint: string, options: RequestInit = {}): Promise<T> {
  const token = getAuthToken();
  const headers: Record<string, string> = {
    'Content-Type': 'application/json',
    ...(options.headers as Record<string, string> || {})
  };

  if (token) {
    headers['Authorization'] = `Bearer ${token}`;
  }

  const res = await fetch(`${API_BASE}${endpoint}`, {
    ...options,
    headers
  });

  const data = await res.json().catch(() => ({}));

  if (!res.ok) {
    const errorMsg = data.error || data.message || `Request failed with status ${res.status}`;
    throw new Error(errorMsg);
  }

  return data as T;
}

export const api = {
  // Auth
  signup: (payload: any) => apiFetch<{ user: any; token: string }>('/auth/signup', { method: 'POST', body: JSON.stringify(payload) }),
  login: (payload: any) => apiFetch<{ user: any; token: string }>('/auth/login', { method: 'POST', body: JSON.stringify(payload) }),
  loginGoogle: (payload: any) => apiFetch<{ user: any; token: string }>('/auth/google', { method: 'POST', body: JSON.stringify(payload) }),
  forgotPassword: (payload: any) => apiFetch<{ success: boolean; message: string; demoCode?: string }>('/auth/forgot-password', { method: 'POST', body: JSON.stringify(payload) }),
  resetPassword: (payload: any) => apiFetch<{ success: boolean; message: string }>('/auth/reset-password', { method: 'POST', body: JSON.stringify(payload) }),
  getMe: () => apiFetch<{ user: any; creatorProfile: any; brandProfile: any; socialAccounts: any[] }>('/auth/me'),

  // Onboarding
  submitOnboarding: (payload: any) => apiFetch<{ success: boolean; user: any }>('/onboarding', { method: 'POST', body: JSON.stringify(payload) }),

  // Dashboard
  getDashboardSummary: () => apiFetch<any>('/dashboard/summary'),

  // Social accounts
  getSocialAccounts: () => apiFetch<any[]>('/social/accounts'),
  addSocialAccount: (payload: any) => apiFetch<any>('/social/accounts', { method: 'POST', body: JSON.stringify(payload) }),
  deleteSocialAccount: (id: string) => apiFetch<any>(`/social/accounts/${id}`, { method: 'DELETE' }),
  verifyYouTube: (handle: string) => apiFetch<any>('/social/youtube/verify', { method: 'POST', body: JSON.stringify({ channelHandle: handle }) }),

  // Content
  getPosts: () => apiFetch<any[]>('/content/posts'),
  createPost: (payload: any) => apiFetch<any>('/content/posts', { method: 'POST', body: JSON.stringify(payload) }),
  updatePost: (id: string, payload: any) => apiFetch<any>(`/content/posts/${id}`, { method: 'PUT', body: JSON.stringify(payload) }),
  deletePost: (id: string) => apiFetch<any>(`/content/posts/${id}`, { method: 'DELETE' }),

  // Campaigns
  getCampaigns: () => apiFetch<any[]>('/campaigns'),
  createCampaign: (payload: any) => apiFetch<any>('/campaigns', { method: 'POST', body: JSON.stringify(payload) }),
  updateCampaign: (id: string, payload: any) => apiFetch<any>(`/campaigns/${id}`, { method: 'PUT', body: JSON.stringify(payload) }),

  // Collaborations
  getCollaborations: () => apiFetch<any[]>('/collaborations'),
  createCollaboration: (payload: any) => apiFetch<any>('/collaborations', { method: 'POST', body: JSON.stringify(payload) }),
  updateCollaboration: (id: string, payload: any) => apiFetch<any>(`/collaborations/${id}`, { method: 'PUT', body: JSON.stringify(payload) }),

  // Discovery
  getDiscoverCreators: () => apiFetch<any[]>('/creators/discover'),

  // Calendar
  getCalendarEvents: () => apiFetch<any[]>('/calendar/events'),
  createCalendarEvent: (payload: any) => apiFetch<any>('/calendar/events', { method: 'POST', body: JSON.stringify(payload) }),
  deleteCalendarEvent: (id: string) => apiFetch<any>(`/calendar/events/${id}`, { method: 'DELETE' }),

  // Analytics
  getAnalytics: () => apiFetch<any[]>('/analytics'),
  recordAnalytics: (payload: any) => apiFetch<any>('/analytics', { method: 'POST', body: JSON.stringify(payload) }),

  // Payments
  getPayments: () => apiFetch<any[]>('/payments'),
  createPayment: (payload: any) => apiFetch<any>('/payments', { method: 'POST', body: JSON.stringify(payload) }),

  // Notifications
  getNotifications: () => apiFetch<any[]>('/notifications'),
  markNotificationRead: (id: string) => apiFetch<any>(`/notifications/${id}/read`, { method: 'PUT' }),
  markAllNotificationsRead: () => apiFetch<any>('/notifications/read-all', { method: 'PUT' }),

  // Settings & Supabase
  updateProfile: (payload: any) => apiFetch<any>('/settings/profile', { method: 'PUT', body: JSON.stringify(payload) }),
  switchRole: (newRole: 'creator' | 'brand') => apiFetch<any>('/settings/switch-role', { method: 'POST', body: JSON.stringify({ newRole }) }),
  getSupabaseStatus: () => apiFetch<any>('/supabase/status'),
  testSupabaseConnection: (url: string, key: string) => apiFetch<any>('/supabase/test', { method: 'POST', body: JSON.stringify({ url, key }) })
};
