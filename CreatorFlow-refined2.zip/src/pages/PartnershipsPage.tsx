import React, { useState, useEffect } from 'react';
import { useAuth } from '../context/AuthContext';
import { api } from '../lib/api';
import {
  Users,
  Search,
  Filter,
  DollarSign,
  MapPin,
  ExternalLink,
  Send,
  Plus,
  Briefcase,
  Youtube,
  Instagram,
  CheckCircle,
  X
} from 'lucide-react';

export const PartnershipsPage: React.FC<{ onNavigate: (tab: string) => void }> = ({ onNavigate }) => {
  const { user } = useAuth();
  const isCreator = user?.role === 'creator';

  const [creators, setCreators] = useState<any[]>([]);
  const [campaigns, setCampaigns] = useState<any[]>([]);
  const [loading, setLoading] = useState<boolean>(true);
  const [search, setSearch] = useState<string>('');
  const [selectedNiche, setSelectedNiche] = useState<string>('all');

  // Brand: Propose deal modal
  const [proposeModal, setProposeModal] = useState<any | null>(null);
  const [offerAmount, setOfferAmount] = useState<number | ''>('');
  const [offerTerms, setOfferTerms] = useState<string>('1x Sponsored Video with product review');
  const [offerNotes, setOfferNotes] = useState<string>('');
  const [sendingOffer, setSendingOffer] = useState<boolean>(false);
  const [offerSuccess, setOfferSuccess] = useState<boolean>(false);

  // Brand: Create campaign modal
  const [campaignModal, setCampaignModal] = useState<boolean>(false);
  const [campTitle, setCampTitle] = useState('');
  const [campDesc, setCampDesc] = useState('');
  const [campBudget, setCampBudget] = useState<number | ''>(2500);
  const [campCategory, setCampCategory] = useState('Tech & Gadgets');
  const [campDeadline, setCampDeadline] = useState(new Date(Date.now() + 30 * 86400000).toISOString().split('T')[0]);
  const [creatingCamp, setCreatingCamp] = useState(false);

  // Creator: Apply to campaign modal
  const [applyModal, setApplyModal] = useState<any | null>(null);
  const [pitchRate, setPitchRate] = useState<number | ''>('');
  const [pitchNotes, setPitchNotes] = useState<string>('');
  const [submittingPitch, setSubmittingPitch] = useState<boolean>(false);

  const fetchData = async () => {
    try {
      setLoading(true);
      if (isCreator) {
        // Creators explore brand campaigns
        const campList = await api.getCampaigns();
        setCampaigns(campList);
      } else {
        // Brands discover creators
        const crList = await api.getDiscoverCreators();
        setCreators(crList);
        const myCamps = await api.getCampaigns();
        setCampaigns(myCamps);
      }
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchData();
  }, [isCreator]);

  const handleSendOffer = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!proposeModal || !offerAmount) return;
    setSendingOffer(true);
    try {
      await api.createCollaboration({
        creatorId: proposeModal.id,
        offeredAmount: Number(offerAmount),
        terms: offerTerms,
        notes: offerNotes,
        deliverables: [
          {
            id: crypto.randomUUID(),
            title: offerTerms,
            platform: proposeModal.primaryPlatform || 'youtube',
            type: 'video',
            status: 'pending',
            dueDate: new Date(Date.now() + 14 * 86400000).toISOString().split('T')[0]
          }
        ]
      });
      setOfferSuccess(true);
      setTimeout(() => {
        setOfferSuccess(false);
        setProposeModal(null);
      }, 1500);
    } catch (err: any) {
      alert(err.message || 'Failed to submit offer');
    } finally {
      setSendingOffer(false);
    }
  };

  const handleCreateCampaign = async (e: React.FormEvent) => {
    e.preventDefault();
    setCreatingCamp(true);
    try {
      await api.createCampaign({
        title: campTitle,
        description: campDesc,
        budget: Number(campBudget),
        category: campCategory,
        requirements: 'Content must include product demo and custom discount code in description.',
        deadline: campDeadline,
        status: 'active'
      });
      setCampaignModal(false);
      setCampTitle('');
      setCampDesc('');
      await fetchData();
    } catch (err: any) {
      alert(err.message || 'Failed to create campaign');
    } finally {
      setCreatingCamp(false);
    }
  };

  const handleCreatorPitch = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!applyModal || !pitchRate) return;
    setSubmittingPitch(true);
    try {
      await api.createCollaboration({
        creatorId: user?.id,
        campaignId: applyModal.id,
        offeredAmount: Number(pitchRate),
        terms: `Campaign Pitch: ${applyModal.title}`,
        notes: pitchNotes
      });
      alert('Application and pitch sent to brand!');
      setApplyModal(null);
      onNavigate('collaborations');
    } catch (err: any) {
      alert(err.message || 'Pitch submission failed');
    } finally {
      setSubmittingPitch(false);
    }
  };

  return (
    <div className="p-6 md:p-8 max-w-7xl mx-auto space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-slate-200 dark:border-slate-800 pb-5">
        <div>
          <h1 className="text-xl md:text-2xl font-bold text-slate-900 dark:text-white">
            {isCreator ? 'Open Brand Campaigns & Pitching' : 'Discover Creators Directory'}
          </h1>
          <p className="text-xs text-slate-500 mt-1">
            {isCreator
              ? 'Browse verified campaigns, submit creative pitches, and secure sponsored partnerships.'
              : 'Filter vetted talent by niche, audience size, engagement, and send direct collaboration offers.'}
          </p>
        </div>

        {!isCreator && (
          <button
            onClick={() => setCampaignModal(true)}
            className="px-3.5 py-2 text-xs font-semibold text-white bg-indigo-600 hover:bg-indigo-700 rounded-lg shadow-xs flex items-center gap-1.5 transition-colors self-start sm:self-auto"
          >
            <Plus className="w-3.5 h-3.5" />
            <span>Launch New Campaign</span>
          </button>
        )}
      </div>

      {/* Search & Filters */}
      <div className="flex flex-wrap items-center justify-between gap-3 bg-white dark:bg-slate-900 p-3 rounded-xl border border-slate-200 dark:border-slate-800">
        <div className="relative flex-1 min-w-[220px] max-w-md">
          <Search className="w-3.5 h-3.5 absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
          <input
            type="text"
            value={search}
            onChange={e => setSearch(e.target.value)}
            placeholder={isCreator ? 'Search campaigns by brand or keyword...' : 'Search creators by name, niche, handle...'}
            className="w-full pl-9 pr-3 py-1.5 text-xs bg-slate-50 dark:bg-slate-800/60 border border-slate-200 dark:border-slate-700 rounded-lg text-slate-900 dark:text-white outline-none"
          />
        </div>
      </div>

      {/* Directory Grid */}
      {loading ? (
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4 animate-pulse">
          {[1, 2, 3].map(i => (
            <div key={i} className="h-60 bg-slate-100 dark:bg-slate-800 rounded-xl" />
          ))}
        </div>
      ) : isCreator ? (
        // CREATOR VIEW: Open Campaigns
        campaigns.length === 0 ? (
          <div className="p-12 text-center bg-white dark:bg-slate-900 rounded-xl border border-slate-200 dark:border-slate-800">
            <Briefcase className="w-8 h-8 text-slate-400 mx-auto mb-3" />
            <h3 className="text-sm font-bold text-slate-900 dark:text-white">No active brand campaigns open right now</h3>
            <p className="text-xs text-slate-500 mt-1 max-w-sm mx-auto">
              Check back soon or switch to Brand mode in the sidebar to launch a campaign yourself!
            </p>
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {campaigns.map(camp => (
              <div
                key={camp.id}
                className="p-5 bg-white dark:bg-slate-900 rounded-xl border border-slate-200 dark:border-slate-800 shadow-xs flex flex-col justify-between space-y-4"
              >
                <div>
                  <div className="flex items-center justify-between text-xs text-slate-500 mb-1">
                    <span className="font-semibold text-indigo-600 dark:text-indigo-400">{camp.category}</span>
                    <span className="font-mono">Deadline: {camp.deadline}</span>
                  </div>
                  <h3 className="text-sm font-bold text-slate-900 dark:text-white">
                    {camp.title}
                  </h3>
                  <div className="text-[11px] text-slate-500 mt-0.5">
                    By: <strong>{camp.brandName || 'Brand Partner'}</strong>
                  </div>
                  <p className="text-xs text-slate-600 dark:text-slate-400 mt-2 line-clamp-3">
                    {camp.description}
                  </p>
                </div>

                <div className="pt-3 border-t border-slate-100 dark:border-slate-800 flex items-center justify-between">
                  <div>
                    <div className="text-sm font-bold font-mono tabular-nums text-slate-900 dark:text-white">
                      ${Number(camp.budget).toLocaleString()}
                    </div>
                    <div className="text-[10px] text-slate-400 capitalize">{camp.compensationType} Fee</div>
                  </div>

                  <button
                    onClick={() => {
                      setApplyModal(camp);
                      setPitchRate(camp.budget);
                    }}
                    className="px-3.5 py-1.5 text-xs font-semibold bg-indigo-600 hover:bg-indigo-700 text-white rounded-lg shadow-xs flex items-center gap-1.5 transition-colors"
                  >
                    <span>Pitch Proposal</span>
                    <Send className="w-3 h-3" />
                  </button>
                </div>
              </div>
            ))}
          </div>
        )
      ) : (
        // BRAND VIEW: Discover Creators
        creators.length === 0 ? (
          <div className="p-12 text-center bg-white dark:bg-slate-900 rounded-xl border border-slate-200 dark:border-slate-800">
            <Users className="w-8 h-8 text-slate-400 mx-auto mb-3" />
            <h3 className="text-sm font-bold text-slate-900 dark:text-white">No creators registered yet</h3>
            <p className="text-xs text-slate-500 mt-1 max-w-sm mx-auto">
              As creators complete their profile and connect accounts, they will be listed here with verified metrics.
            </p>
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {creators.map(cr => (
              <div
                key={cr.id}
                className="p-5 bg-white dark:bg-slate-900 rounded-xl border border-slate-200 dark:border-slate-800 shadow-xs flex flex-col justify-between space-y-4"
              >
                <div>
                  <div className="flex items-center gap-3">
                    {cr.avatarUrl ? (
                      <img
                        src={cr.avatarUrl}
                        alt={cr.fullName}
                        referrerPolicy="no-referrer"
                        className="w-12 h-12 rounded-full object-cover border border-slate-200 shrink-0"
                      />
                    ) : (
                      <div className="w-12 h-12 rounded-full bg-slate-200 dark:bg-slate-700 flex items-center justify-center font-bold text-slate-700 dark:text-slate-300 shrink-0">
                        {cr.fullName.charAt(0)}
                      </div>
                    )}
                    <div className="min-w-0">
                      <h3 className="text-xs font-bold text-slate-900 dark:text-white truncate">
                        {cr.fullName}
                      </h3>
                      <div className="text-[11px] text-slate-500">{cr.niche} · {cr.location}</div>
                    </div>
                  </div>

                  <p className="text-xs text-slate-600 dark:text-slate-400 mt-3 line-clamp-2">
                    {cr.bio}
                  </p>

                  {/* Connected channels pills */}
                  <div className="mt-3 flex items-center gap-2 text-[11px] text-slate-500">
                    <span className="font-mono font-bold text-slate-900 dark:text-white tabular-nums">
                      {cr.totalFollowers.toLocaleString()}
                    </span>
                    <span>followers</span>
                    <span aria-hidden="true">·</span>
                    <span className="font-mono font-bold text-indigo-600 tabular-nums">
                      {cr.engagementRate}%
                    </span>
                    <span>ER</span>
                  </div>
                </div>

                <div className="pt-3 border-t border-slate-100 dark:border-slate-800 flex items-center justify-between">
                  <div>
                    <div className="text-xs font-mono font-bold text-slate-900 dark:text-white">
                      From ${cr.rateVideo || cr.rateReel || 250}
                    </div>
                    <div className="text-[10px] text-slate-400">Baseline Rate</div>
                  </div>

                  <button
                    onClick={() => {
                      setProposeModal(cr);
                      setOfferAmount(cr.rateVideo || cr.rateReel || 500);
                    }}
                    className="px-3.5 py-1.5 text-xs font-semibold bg-indigo-600 hover:bg-indigo-700 text-white rounded-lg shadow-xs flex items-center gap-1.5 transition-colors"
                  >
                    <span>Send Deal Offer</span>
                    <Send className="w-3 h-3" />
                  </button>
                </div>
              </div>
            ))}
          </div>
        )
      )}

      {/* Brand Send Deal Modal */}
      {proposeModal && (
        <div className="fixed inset-0 bg-slate-900/50 backdrop-blur-xs flex items-center justify-center p-4 z-50">
          <div className="bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 max-w-md w-full p-6 shadow-xl">
            <div className="flex items-center justify-between pb-3 border-b border-slate-200 dark:border-slate-800">
              <h2 className="text-sm font-bold text-slate-900 dark:text-white">
                Propose Deal to {proposeModal.fullName}
              </h2>
              <button onClick={() => setProposeModal(null)} className="text-slate-400 hover:text-slate-600">
                <X className="w-4 h-4" />
              </button>
            </div>

            {offerSuccess ? (
              <div className="py-8 text-center text-emerald-600 text-xs font-bold space-y-2">
                <CheckCircle className="w-8 h-8 mx-auto" />
                <p>Collaboration proposal sent and stored in database!</p>
              </div>
            ) : (
              <form onSubmit={handleSendOffer} className="mt-4 space-y-4">
                <div>
                  <label className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1">
                    Offered Compensation ($ USD)
                  </label>
                  <input
                    type="number"
                    required
                    value={offerAmount}
                    onChange={e => setOfferAmount(Number(e.target.value))}
                    className="w-full px-3 py-2 text-xs font-mono tabular-nums border border-slate-300 dark:border-slate-700 rounded-lg bg-white dark:bg-slate-800 text-slate-900 dark:text-white"
                  />
                </div>

                <div>
                  <label className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1">
                    Scope & Deliverables
                  </label>
                  <input
                    type="text"
                    required
                    value={offerTerms}
                    onChange={e => setOfferTerms(e.target.value)}
                    placeholder="e.g. 1x Dedicated YouTube Review (8-10 min)"
                    className="w-full px-3 py-2 text-xs border border-slate-300 dark:border-slate-700 rounded-lg bg-white dark:bg-slate-800 text-slate-900 dark:text-white"
                  />
                </div>

                <div>
                  <label className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1">
                    Campaign Brief & Creative Guidelines
                  </label>
                  <textarea
                    rows={3}
                    value={offerNotes}
                    onChange={e => setOfferNotes(e.target.value)}
                    placeholder="Key talking points, timeline, product shipment details..."
                    className="w-full px-3 py-2 text-xs border border-slate-300 dark:border-slate-700 rounded-lg bg-white dark:bg-slate-800 text-slate-900 dark:text-white"
                  />
                </div>

                <div className="flex justify-end gap-2 pt-2">
                  <button
                    type="button"
                    onClick={() => setProposeModal(null)}
                    className="px-3 py-1.5 text-xs text-slate-600 hover:text-slate-800"
                  >
                    Cancel
                  </button>
                  <button
                    type="submit"
                    disabled={sendingOffer}
                    className="px-4 py-1.5 text-xs font-semibold bg-indigo-600 hover:bg-indigo-700 text-white rounded-lg shadow-xs"
                  >
                    {sendingOffer ? 'Sending...' : 'Send Offer & Notify Creator'}
                  </button>
                </div>
              </form>
            )}
          </div>
        </div>
      )}

      {/* Brand Create Campaign Modal */}
      {campaignModal && (
        <div className="fixed inset-0 bg-slate-900/50 backdrop-blur-xs flex items-center justify-center p-4 z-50">
          <div className="bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 max-w-md w-full p-6 shadow-xl">
            <div className="flex items-center justify-between pb-3 border-b border-slate-200 dark:border-slate-800">
              <h2 className="text-sm font-bold text-slate-900 dark:text-white">
                Launch Brand Marketing Campaign
              </h2>
              <button onClick={() => setCampaignModal(false)} className="text-slate-400 hover:text-slate-600">
                <X className="w-4 h-4" />
              </button>
            </div>

            <form onSubmit={handleCreateCampaign} className="mt-4 space-y-4">
              <div>
                <label className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1">
                  Campaign Title
                </label>
                <input
                  type="text"
                  required
                  value={campTitle}
                  onChange={e => setCampTitle(e.target.value)}
                  placeholder="e.g. Q4 Flagship Smart Audio Launch"
                  className="w-full px-3 py-2 text-xs border border-slate-300 dark:border-slate-700 rounded-lg bg-white dark:bg-slate-800 text-slate-900 dark:text-white"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1">
                    Campaign Budget ($)
                  </label>
                  <input
                    type="number"
                    required
                    value={campBudget}
                    onChange={e => setCampBudget(Number(e.target.value))}
                    className="w-full px-3 py-2 text-xs font-mono tabular-nums border border-slate-300 dark:border-slate-700 rounded-lg bg-white dark:bg-slate-800 text-slate-900 dark:text-white"
                  />
                </div>
                <div>
                  <label className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1">
                    Application Deadline
                  </label>
                  <input
                    type="date"
                    required
                    value={campDeadline}
                    onChange={e => setCampDeadline(e.target.value)}
                    className="w-full px-3 py-1.5 text-xs font-mono border border-slate-300 dark:border-slate-700 rounded-lg bg-white dark:bg-slate-800 text-slate-900 dark:text-white"
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1">
                  Campaign Description & Requirements
                </label>
                <textarea
                  rows={3}
                  required
                  value={campDesc}
                  onChange={e => setCampDesc(e.target.value)}
                  placeholder="Describe your product, desired content format, audience age group, and key objectives..."
                  className="w-full px-3 py-2 text-xs border border-slate-300 dark:border-slate-700 rounded-lg bg-white dark:bg-slate-800 text-slate-900 dark:text-white"
                />
              </div>

              <div className="flex justify-end gap-2 pt-2">
                <button
                  type="button"
                  onClick={() => setCampaignModal(false)}
                  className="px-3 py-1.5 text-xs text-slate-600 hover:text-slate-800"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={creatingCamp}
                  className="px-4 py-1.5 text-xs font-semibold bg-indigo-600 hover:bg-indigo-700 text-white rounded-lg shadow-xs"
                >
                  {creatingCamp ? 'Publishing...' : 'Publish Campaign'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Creator Pitch Modal */}
      {applyModal && (
        <div className="fixed inset-0 bg-slate-900/50 backdrop-blur-xs flex items-center justify-center p-4 z-50">
          <div className="bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 max-w-md w-full p-6 shadow-xl">
            <h2 className="text-sm font-bold text-slate-900 dark:text-white mb-1">
              Apply to: {applyModal.title}
            </h2>
            <p className="text-xs text-slate-500 mb-4">
              Budget: ${applyModal.budget} · Hosted by {applyModal.brandName}
            </p>

            <form onSubmit={handleCreatorPitch} className="space-y-4">
              <div>
                <label className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1">
                  Your Proposed Rate ($ USD)
                </label>
                <input
                  type="number"
                  required
                  value={pitchRate}
                  onChange={e => setPitchRate(Number(e.target.value))}
                  className="w-full px-3 py-2 text-xs font-mono tabular-nums border border-slate-300 dark:border-slate-700 rounded-lg bg-white dark:bg-slate-800 text-slate-900 dark:text-white"
                />
              </div>

              <div>
                <label className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1">
                  Your Pitch & Creative Concept
                </label>
                <textarea
                  rows={3}
                  required
                  value={pitchNotes}
                  onChange={e => setPitchNotes(e.target.value)}
                  placeholder="Explain why your audience is a perfect fit, your content angle, and expected reach..."
                  className="w-full px-3 py-2 text-xs border border-slate-300 dark:border-slate-700 rounded-lg bg-white dark:bg-slate-800 text-slate-900 dark:text-white"
                />
              </div>

              <div className="flex justify-end gap-2 pt-2">
                <button
                  type="button"
                  onClick={() => setApplyModal(null)}
                  className="px-3 py-1.5 text-xs text-slate-600 hover:text-slate-800"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={submittingPitch}
                  className="px-4 py-1.5 text-xs font-semibold bg-indigo-600 hover:bg-indigo-700 text-white rounded-lg shadow-xs"
                >
                  {submittingPitch ? 'Submitting...' : 'Submit Campaign Pitch'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
