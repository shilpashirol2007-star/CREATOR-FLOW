import React, { useState, useEffect } from 'react';
import { useAuth } from '../context/AuthContext';
import { api } from '../lib/api';
import { Collaboration, CollabStatus } from '../types';
import {
  Briefcase,
  CheckCircle,
  XCircle,
  Clock,
  ArrowRightLeft,
  DollarSign,
  ExternalLink,
  ShieldCheck,
  Check,
  Send,
  MessageSquare,
  AlertCircle
} from 'lucide-react';

export const CollaborationsPage: React.FC = () => {
  const { user } = useAuth();
  const isCreator = user?.role === 'creator';

  const [collabs, setCollabs] = useState<Collaboration[]>([]);
  const [loading, setLoading] = useState<boolean>(true);
  const [filter, setFilter] = useState<string>('all');
  const [actionLoading, setActionLoading] = useState<string | null>(null);

  // Negotiate modal
  const [negotiateModal, setNegotiateModal] = useState<Collaboration | null>(null);
  const [counterAmount, setCounterAmount] = useState<number | ''>('');
  const [negotiateNote, setNegotiateNote] = useState<string>('');

  // Submit proof modal
  const [proofModal, setProofModal] = useState<{ collab: Collaboration; deliverableIndex: number } | null>(null);
  const [proofUrl, setProofUrl] = useState<string>('');

  const fetchCollabs = async () => {
    try {
      setLoading(true);
      const res = await api.getCollaborations();
      setCollabs(res);
    } catch (err) {
      console.error('Failed to load collaborations:', err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchCollabs();
  }, []);

  const handleAction = async (id: string, action: 'accept' | 'reject') => {
    setActionLoading(id);
    try {
      await api.updateCollaboration(id, { action });
      await fetchCollabs();
    } catch (err: any) {
      alert(err.message || 'Action failed');
    } finally {
      setActionLoading(null);
    }
  };

  const submitNegotiation = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!negotiateModal || !counterAmount) return;
    setActionLoading(negotiateModal.id);
    try {
      await api.updateCollaboration(negotiateModal.id, {
        action: 'negotiate',
        counterAmount: Number(counterAmount),
        notes: negotiateNote
      });
      setNegotiateModal(null);
      await fetchCollabs();
    } catch (err: any) {
      alert(err.message || 'Failed to submit counter-offer');
    } finally {
      setActionLoading(null);
    }
  };

  const handleDeliverableStatus = async (collab: Collaboration, index: number, newStatus: any) => {
    const updated = [...(collab.deliverables || [])];
    updated[index] = { ...updated[index], status: newStatus };
    try {
      await api.updateCollaboration(collab.id, { deliverables: updated });
      await fetchCollabs();
    } catch (err) {
      console.error(err);
    }
  };

  const submitProofUrl = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!proofModal) return;
    const { collab, deliverableIndex } = proofModal;
    const updated = [...(collab.deliverables || [])];
    updated[deliverableIndex] = {
      ...updated[deliverableIndex],
      proofUrl,
      status: 'submitted'
    };

    try {
      await api.updateCollaboration(collab.id, { deliverables: updated });
      setProofModal(null);
      setProofUrl('');
      await fetchCollabs();
    } catch (err: any) {
      alert(err.message || 'Failed to submit deliverable proof');
    }
  };

  const handleReleasePayment = async (collab: Collaboration) => {
    if (!confirm(`Release $${collab.agreedAmount} from Escrow to ${collab.creatorName}?`)) return;
    setActionLoading(collab.id);
    try {
      await api.updateCollaboration(collab.id, { paymentStatus: 'released' });
      await fetchCollabs();
    } catch (err: any) {
      alert(err.message || 'Payment release failed');
    } finally {
      setActionLoading(null);
    }
  };

  const filtered = collabs.filter(c => {
    if (filter === 'all') return true;
    if (filter === 'offers') return c.status === 'requested';
    if (filter === 'negotiating') return c.status === 'negotiating';
    if (filter === 'active') return ['accepted', 'in_progress'].includes(c.status);
    if (filter === 'completed') return c.status === 'completed';
    return true;
  });

  return (
    <div className="p-6 md:p-8 max-w-7xl mx-auto space-y-6">
      {/* Header */}
      <div className="border-b border-slate-200 dark:border-slate-800 pb-5">
        <h1 className="text-xl md:text-2xl font-bold text-slate-900 dark:text-white">
          Brand Collaborations & Deals
        </h1>
        <p className="text-xs text-slate-500 mt-1">
          {isCreator
            ? 'Review incoming proposals, negotiate terms, fulfill milestones, and receive secured escrow payouts.'
            : 'Track sponsored creator deliverables, approve submitted content, and manage escrow disbursements.'}
        </p>
      </div>

      {/* Filter Tabs */}
      <div className="flex items-center gap-1.5 p-1 bg-slate-100 dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-lg max-w-md">
        {[
          { id: 'all', label: 'All Deals' },
          { id: 'offers', label: 'Offers' },
          { id: 'negotiating', label: 'Negotiating' },
          { id: 'active', label: 'Active' },
          { id: 'completed', label: 'Completed' }
        ].map(tab => (
          <button
            key={tab.id}
            onClick={() => setFilter(tab.id)}
            className={`flex-1 py-1.5 text-xs font-semibold rounded-md transition-colors text-center ${
              filter === tab.id
                ? 'bg-white dark:bg-slate-800 text-slate-900 dark:text-white shadow-xs'
                : 'text-slate-600 dark:text-slate-400 hover:text-slate-900'
            }`}
          >
            {tab.label}
          </button>
        ))}
      </div>

      {loading ? (
        <div className="space-y-4 animate-pulse">
          {[1, 2, 3].map(i => (
            <div key={i} className="h-44 bg-slate-100 dark:bg-slate-800 rounded-xl" />
          ))}
        </div>
      ) : filtered.length === 0 ? (
        <div className="p-12 text-center bg-white dark:bg-slate-900 rounded-xl border border-slate-200 dark:border-slate-800">
          <Briefcase className="w-8 h-8 text-slate-400 mx-auto mb-3" />
          <h3 className="text-sm font-bold text-slate-900 dark:text-white">No collaborations in this category</h3>
          <p className="text-xs text-slate-500 mt-1 max-w-sm mx-auto">
            {isCreator
              ? 'Incoming partnership requests from brands will appear here with rates and deliverables.'
              : 'Browse our creator directory to pitch campaigns and send collaboration offers.'}
          </p>
        </div>
      ) : (
        <div className="space-y-4">
          {filtered.map(collab => {
            const isOffer = collab.status === 'requested';
            const isNegotiating = collab.status === 'negotiating';
            const isActive = ['accepted', 'in_progress'].includes(collab.status);
            const isCompleted = collab.status === 'completed';

            return (
              <div
                key={collab.id}
                className="p-5 bg-white dark:bg-slate-900 rounded-xl border border-slate-200 dark:border-slate-800 shadow-xs space-y-4"
              >
                {/* Top Row */}
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-slate-100 dark:border-slate-800 pb-3">
                  <div>
                    <div className="flex items-center gap-2">
                      <span className="text-sm font-bold text-slate-900 dark:text-white">
                        {collab.campaignTitle || 'Custom Commercial Partnership'}
                      </span>
                      <span className="text-xs text-slate-500">
                        · Partner: <strong className="text-slate-800 dark:text-slate-200">{isCreator ? collab.brandName : collab.creatorName}</strong>
                      </span>
                    </div>
                    <div className="text-[11px] text-slate-500 mt-0.5">
                      Contract ID: <span className="font-mono">{collab.id.slice(0, 8)}</span> · Created: {new Date(collab.createdAt).toLocaleDateString()}
                    </div>
                  </div>

                  <div className="flex items-center gap-3">
                    <div className="text-right">
                      <div className="text-base font-bold font-mono tabular-nums text-indigo-600 dark:text-indigo-400">
                        ${collab.agreedAmount || collab.offeredAmount}
                      </div>
                      <div className="text-[10px] text-slate-400 capitalize">
                        {collab.paymentStatus === 'released' ? 'Payout Released' : collab.paymentStatus === 'in_escrow' ? 'Secured in Escrow' : 'Unpaid Offer'}
                      </div>
                    </div>

                    <div className="px-2.5 py-1 text-xs font-semibold rounded capitalize bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300">
                      {collab.status}
                    </div>
                  </div>
                </div>

                {/* Terms and Notes */}
                <div className="text-xs text-slate-600 dark:text-slate-300 space-y-1">
                  <div><strong className="text-slate-900 dark:text-white">Contract Terms:</strong> {collab.terms}</div>
                  {collab.brandNotes && <div><strong className="text-slate-900 dark:text-white">Brand Brief:</strong> {collab.brandNotes}</div>}
                  {collab.creatorNotes && <div><strong className="text-slate-900 dark:text-white">Creator Response:</strong> {collab.creatorNotes}</div>}
                </div>

                {/* Deliverables Checklist */}
                <div className="pt-2">
                  <span className="text-xs font-bold text-slate-800 dark:text-slate-200 block mb-2">
                    Deliverables & Milestones:
                  </span>
                  <div className="space-y-2">
                    {collab.deliverables?.map((del, idx) => (
                      <div
                        key={del.id || idx}
                        className="p-3 rounded-lg border border-slate-200 dark:border-slate-800 bg-slate-50/50 dark:bg-slate-800/40 flex flex-col sm:flex-row sm:items-center justify-between gap-2"
                      >
                        <div className="flex items-center gap-2.5">
                          <div className={`w-5 h-5 rounded-full flex items-center justify-center text-xs font-bold ${
                            del.status === 'approved' || del.status === 'published'
                              ? 'bg-emerald-600 text-white'
                              : del.status === 'submitted'
                              ? 'bg-amber-500 text-white'
                              : 'bg-slate-200 dark:bg-slate-700 text-slate-600 dark:text-slate-400'
                          }`}>
                            {del.status === 'approved' || del.status === 'published' ? <Check className="w-3 h-3" /> : idx + 1}
                          </div>
                          <div>
                            <div className="text-xs font-semibold text-slate-900 dark:text-white">{del.title}</div>
                            <div className="text-[11px] text-slate-500">
                              Format: <span className="capitalize">{del.type}</span> · Due: <span className="font-mono">{del.dueDate}</span>
                            </div>
                          </div>
                        </div>

                        <div className="flex items-center gap-2 self-end sm:self-auto">
                          {del.proofUrl && (
                            <a
                              href={del.proofUrl}
                              target="_blank"
                              rel="noreferrer"
                              className="text-[11px] text-indigo-600 dark:text-indigo-400 font-medium hover:underline flex items-center gap-1 mr-2"
                            >
                              <span>View Proof URL</span>
                              <ExternalLink className="w-3 h-3" />
                            </a>
                          )}

                          {isCreator ? (
                            del.status !== 'approved' && del.status !== 'published' && (
                              <button
                                onClick={() => setProofModal({ collab, deliverableIndex: idx })}
                                className="px-2.5 py-1 text-xs font-medium bg-indigo-50 dark:bg-indigo-950/40 text-indigo-700 dark:text-indigo-300 rounded hover:bg-indigo-100 transition-colors"
                              >
                                {del.proofUrl ? 'Update Proof' : 'Submit Proof'}
                              </button>
                            )
                          ) : (
                            // Brand actions on deliverables
                            del.status === 'submitted' && (
                              <button
                                onClick={() => handleDeliverableStatus(collab, idx, 'approved')}
                                className="px-2.5 py-1 text-xs font-medium bg-emerald-600 text-white rounded hover:bg-emerald-700 transition-colors flex items-center gap-1"
                              >
                                <Check className="w-3 h-3" />
                                <span>Approve Deliverable</span>
                              </button>
                            )
                          )}
                        </div>
                      </div>
                    ))}
                  </div>
                </div>

                {/* Action buttons row */}
                <div className="pt-3 border-t border-slate-100 dark:border-slate-800 flex flex-wrap items-center justify-between gap-3">
                  <div className="flex items-center gap-2 text-xs text-slate-500">
                    <ShieldCheck className="w-4 h-4 text-emerald-600" />
                    <span>Protected by CreatorFlow Commercial Terms</span>
                  </div>

                  <div className="flex items-center gap-2">
                    {/* Creator Action Buttons on New Offers */}
                    {isCreator && isOffer && (
                      <>
                        <button
                          onClick={() => handleAction(collab.id, 'reject')}
                          disabled={actionLoading === collab.id}
                          className="px-3 py-1.5 text-xs font-medium border border-rose-300 text-rose-700 hover:bg-rose-50 rounded-lg transition-colors"
                        >
                          Decline
                        </button>
                        <button
                          onClick={() => {
                            setNegotiateModal(collab);
                            setCounterAmount(collab.offeredAmount);
                          }}
                          className="px-3 py-1.5 text-xs font-medium border border-slate-300 dark:border-slate-700 text-slate-700 dark:text-slate-300 rounded-lg hover:bg-slate-50 transition-colors"
                        >
                          Negotiate Rate
                        </button>
                        <button
                          onClick={() => handleAction(collab.id, 'accept')}
                          disabled={actionLoading === collab.id}
                          className="px-4 py-1.5 text-xs font-semibold bg-emerald-600 hover:bg-emerald-700 text-white rounded-lg shadow-xs transition-colors flex items-center gap-1.5"
                        >
                          <Check className="w-3.5 h-3.5" />
                          <span>Accept & Fund Escrow</span>
                        </button>
                      </>
                    )}

                    {/* Brand Action to Release Payment */}
                    {!isCreator && isActive && collab.paymentStatus === 'in_escrow' && (
                      <button
                        onClick={() => handleReleasePayment(collab)}
                        disabled={actionLoading === collab.id}
                        className="px-4 py-1.5 text-xs font-semibold bg-emerald-600 hover:bg-emerald-700 text-white rounded-lg shadow-xs transition-colors flex items-center gap-1.5"
                      >
                        <DollarSign className="w-3.5 h-3.5" />
                        <span>Release Payout to Creator</span>
                      </button>
                    )}
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      )}

      {/* Negotiate Modal */}
      {negotiateModal && (
        <div className="fixed inset-0 bg-slate-900/50 backdrop-blur-xs flex items-center justify-center p-4 z-50">
          <div className="bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 max-w-md w-full p-6 shadow-xl">
            <h2 className="text-sm font-bold text-slate-900 dark:text-white mb-2">
              Counter-Offer & Terms Negotiation
            </h2>
            <p className="text-xs text-slate-500 mb-4">
              Propose a revised fee or modified deliverable schedule to {negotiateModal.brandName}.
            </p>

            <form onSubmit={submitNegotiation} className="space-y-4">
              <div>
                <label className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1">
                  Proposed Fee ($ USD)
                </label>
                <input
                  type="number"
                  required
                  value={counterAmount}
                  onChange={e => setCounterAmount(Number(e.target.value))}
                  className="w-full px-3 py-2 text-xs font-mono tabular-nums border border-slate-300 dark:border-slate-700 rounded-lg bg-white dark:bg-slate-800 text-slate-900 dark:text-white"
                />
              </div>

              <div>
                <label className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1">
                  Negotiation Note / Rationale
                </label>
                <textarea
                  rows={3}
                  value={negotiateNote}
                  onChange={e => setNegotiateNote(e.target.value)}
                  placeholder="e.g. My average reel generates 45k impressions. I propose $650 with 30-day usage rights included."
                  className="w-full px-3 py-2 text-xs border border-slate-300 dark:border-slate-700 rounded-lg bg-white dark:bg-slate-800 text-slate-900 dark:text-white"
                />
              </div>

              <div className="flex justify-end gap-2 pt-2">
                <button
                  type="button"
                  onClick={() => setNegotiateModal(null)}
                  className="px-3 py-1.5 text-xs text-slate-600 hover:text-slate-800"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-4 py-1.5 text-xs font-semibold bg-indigo-600 hover:bg-indigo-700 text-white rounded-lg shadow-xs"
                >
                  Send Counter-Offer
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Submit Proof Modal */}
      {proofModal && (
        <div className="fixed inset-0 bg-slate-900/50 backdrop-blur-xs flex items-center justify-center p-4 z-50">
          <div className="bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 max-w-md w-full p-6 shadow-xl">
            <h2 className="text-sm font-bold text-slate-900 dark:text-white mb-2">
              Submit Deliverable Proof Link
            </h2>
            <p className="text-xs text-slate-500 mb-4">
              Provide the live publication link or unlisted preview for brand review.
            </p>

            <form onSubmit={submitProofUrl} className="space-y-4">
              <div>
                <label className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1">
                  Live Post / Video URL
                </label>
                <input
                  type="url"
                  required
                  value={proofUrl}
                  onChange={e => setProofUrl(e.target.value)}
                  placeholder="https://youtube.com/watch?v=... or https://instagram.com/reel/..."
                  className="w-full px-3 py-2 text-xs border border-slate-300 dark:border-slate-700 rounded-lg bg-white dark:bg-slate-800 text-slate-900 dark:text-white"
                />
              </div>

              <div className="flex justify-end gap-2 pt-2">
                <button
                  type="button"
                  onClick={() => setProofModal(null)}
                  className="px-3 py-1.5 text-xs text-slate-600 hover:text-slate-800"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-4 py-1.5 text-xs font-semibold bg-emerald-600 hover:bg-emerald-700 text-white rounded-lg shadow-xs"
                >
                  Submit for Approval
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
