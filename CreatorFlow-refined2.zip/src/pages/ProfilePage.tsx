import React, { useState } from 'react';
import { useAuth } from '../context/AuthContext';
import { api } from '../lib/api';
import { User, MapPin, Globe, DollarSign, Check, ExternalLink, Save, Plus, X } from 'lucide-react';

export const ProfilePage: React.FC = () => {
  const { user, creatorProfile, brandProfile, refreshUser } = useAuth();
  const isCreator = user?.role === 'creator';

  const [fullName, setFullName] = useState(user?.fullName || '');
  const [avatarUrl, setAvatarUrl] = useState(user?.avatarUrl || '');
  const [phone, setPhone] = useState(user?.phone || '');

  // Creator profile state
  const [bio, setBio] = useState(creatorProfile?.bio || '');
  const [niche, setNiche] = useState(creatorProfile?.niche || 'Lifestyle & Tech');
  const [location, setLocation] = useState(creatorProfile?.location || 'Remote');
  const [website, setWebsite] = useState(creatorProfile?.website || '');
  const [ratePost, setRatePost] = useState<number>(creatorProfile?.ratePost || 250);
  const [rateVideo, setRateVideo] = useState<number>(creatorProfile?.rateVideo || 850);
  const [rateReel, setRateReel] = useState<number>(creatorProfile?.rateReel || 400);
  const [rateStory, setRateStory] = useState<number>(creatorProfile?.rateStory || 150);

  // Brand profile state
  const [companyName, setCompanyName] = useState(brandProfile?.companyName || user?.fullName || '');
  const [industry, setIndustry] = useState(brandProfile?.industry || 'Consumer Goods');
  const [brandDesc, setBrandDesc] = useState(brandProfile?.description || '');

  const [saving, setSaving] = useState(false);
  const [savedSuccess, setSavedSuccess] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const handleSave = async (e: React.FormEvent) => {
    e.preventDefault();
    setSaving(true);
    setError(null);
    setSavedSuccess(false);

    try {
      if (isCreator) {
        await api.updateProfile({
          fullName,
          avatarUrl,
          phone,
          bio,
          niche,
          location,
          website
        });
        // Also update onboarding table fields if needed
        await api.submitOnboarding({
          fullName,
          avatarUrl,
          phone,
          bio,
          niche,
          location,
          website,
          ratePost,
          rateVideo,
          rateReel,
          rateStory
        });
      } else {
        await api.updateProfile({
          fullName,
          avatarUrl,
          phone,
          companyName,
          industry,
          website,
          description: brandDesc
        });
      }

      await refreshUser();
      setSavedSuccess(true);
      setTimeout(() => setSavedSuccess(false), 3000);
    } catch (err: any) {
      setError(err.message || 'Failed to update profile');
    } finally {
      setSaving(false);
    }
  };

  return (
    <div className="p-6 md:p-8 max-w-5xl mx-auto space-y-6">
      <div className="border-b border-slate-200 dark:border-slate-800 pb-5">
        <h1 className="text-xl md:text-2xl font-bold text-slate-900 dark:text-white">
          {isCreator ? 'Creator Profile & Media Kit' : 'Brand Profile & Agency Settings'}
        </h1>
        <p className="text-xs text-slate-500 mt-1">
          {isCreator
            ? 'Your public representation shown to brands during discovery and deal proposals.'
            : 'Company details and campaign requirements presented to creators.'}
        </p>
      </div>

      {savedSuccess && (
        <div className="p-3 bg-emerald-50 border border-emerald-200 text-xs font-semibold text-emerald-800 rounded-lg flex items-center gap-2">
          <Check className="w-4 h-4 text-emerald-600" />
          <span>Profile updated and synchronized to database successfully.</span>
        </div>
      )}

      {error && (
        <div className="p-3 bg-rose-50 border border-rose-200 text-xs font-semibold text-rose-800 rounded-lg">
          {error}
        </div>
      )}

      <form onSubmit={handleSave} className="space-y-6">
        {/* Profile Card */}
        <div className="p-6 bg-white dark:bg-slate-900 rounded-xl border border-slate-200 dark:border-slate-800 shadow-xs space-y-5">
          <h2 className="text-sm font-bold text-slate-900 dark:text-white border-b border-slate-100 dark:border-slate-800 pb-2">
            General Information
          </h2>

          <div className="flex flex-col sm:flex-row items-start sm:items-center gap-4">
            {avatarUrl ? (
              <img
                src={avatarUrl}
                alt={fullName}
                referrerPolicy="no-referrer"
                className="w-16 h-16 rounded-full object-cover border-2 border-indigo-500 shrink-0"
              />
            ) : (
              <div className="w-16 h-16 rounded-full bg-slate-200 dark:bg-slate-700 flex items-center justify-center font-bold text-slate-700 dark:text-slate-300 shrink-0">
                {fullName.charAt(0) || 'U'}
              </div>
            )}
            <div className="flex-1 space-y-1.5 w-full">
              <label className="block text-xs font-medium text-slate-700 dark:text-slate-300">
                Avatar Image URL
              </label>
              <input
                type="text"
                value={avatarUrl}
                onChange={e => setAvatarUrl(e.target.value)}
                placeholder="/src/assets/images/creator_avatar_female_... or https://..."
                className="w-full px-3 py-1.5 text-xs border border-slate-300 dark:border-slate-700 rounded-lg bg-white dark:bg-slate-800 text-slate-900 dark:text-white outline-none"
              />
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1">
                {isCreator ? 'Creator Display Name' : 'Company / Brand Name'}
              </label>
              <input
                type="text"
                required
                value={isCreator ? fullName : companyName}
                onChange={e => isCreator ? setFullName(e.target.value) : setCompanyName(e.target.value)}
                className="w-full px-3 py-2 text-xs border border-slate-300 dark:border-slate-700 rounded-lg bg-white dark:bg-slate-800 text-slate-900 dark:text-white outline-none"
              />
            </div>
            <div>
              <label className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1">
                Account Email (Read-Only)
              </label>
              <input
                type="email"
                disabled
                value={user?.email || ''}
                className="w-full px-3 py-2 text-xs border border-slate-200 dark:border-slate-800 rounded-lg bg-slate-100 dark:bg-slate-800/50 text-slate-500 cursor-not-allowed"
              />
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1">
                {isCreator ? 'Content Niche' : 'Industry Category'}
              </label>
              <input
                type="text"
                value={isCreator ? niche : industry}
                onChange={e => isCreator ? setNiche(e.target.value) : setIndustry(e.target.value)}
                className="w-full px-3 py-2 text-xs border border-slate-300 dark:border-slate-700 rounded-lg bg-white dark:bg-slate-800 text-slate-900 dark:text-white outline-none"
              />
            </div>
            <div>
              <label className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1">
                Location / City
              </label>
              <input
                type="text"
                value={location}
                onChange={e => setLocation(e.target.value)}
                placeholder="e.g. Austin, TX"
                className="w-full px-3 py-2 text-xs border border-slate-300 dark:border-slate-700 rounded-lg bg-white dark:bg-slate-800 text-slate-900 dark:text-white outline-none"
              />
            </div>
          </div>

          <div>
            <label className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1">
              Website / Portfolio Link
            </label>
            <input
              type="url"
              value={website}
              onChange={e => setWebsite(e.target.value)}
              placeholder="https://mychannel.com"
              className="w-full px-3 py-2 text-xs border border-slate-300 dark:border-slate-700 rounded-lg bg-white dark:bg-slate-800 text-slate-900 dark:text-white outline-none"
            />
          </div>

          <div>
            <label className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1">
              {isCreator ? 'Creator Biography & Pitch' : 'Brand Overview & Mission'}
            </label>
            <textarea
              rows={4}
              value={isCreator ? bio : brandDesc}
              onChange={e => isCreator ? setBio(e.target.value) : setBrandDesc(e.target.value)}
              className="w-full px-3 py-2 text-xs border border-slate-300 dark:border-slate-700 rounded-lg bg-white dark:bg-slate-800 text-slate-900 dark:text-white outline-none"
            />
          </div>
        </div>

        {/* Creator Rate Card Section */}
        {isCreator && (
          <div className="p-6 bg-white dark:bg-slate-900 rounded-xl border border-slate-200 dark:border-slate-800 shadow-xs space-y-4">
            <h2 className="text-sm font-bold text-slate-900 dark:text-white border-b border-slate-100 dark:border-slate-800 pb-2">
              Commercial Rate Card
            </h2>
            <p className="text-xs text-slate-500">
              Advertised starting fees per deliverable type presented to discovering brand partners.
            </p>

            <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
              <div className="p-3 rounded-lg border border-slate-200 dark:border-slate-800 bg-slate-50/50 dark:bg-slate-800/40">
                <span className="text-[11px] font-medium text-slate-600 dark:text-slate-400 block mb-1">
                  Dedicated Video ($)
                </span>
                <input
                  type="number"
                  value={rateVideo}
                  onChange={e => setRateVideo(Number(e.target.value))}
                  className="w-full px-2 py-1.5 text-xs font-mono tabular-nums border border-slate-300 dark:border-slate-700 rounded bg-white dark:bg-slate-900 text-slate-900 dark:text-white"
                />
              </div>

              <div className="p-3 rounded-lg border border-slate-200 dark:border-slate-800 bg-slate-50/50 dark:bg-slate-800/40">
                <span className="text-[11px] font-medium text-slate-600 dark:text-slate-400 block mb-1">
                  Reel / Short ($)
                </span>
                <input
                  type="number"
                  value={rateReel}
                  onChange={e => setRateReel(Number(e.target.value))}
                  className="w-full px-2 py-1.5 text-xs font-mono tabular-nums border border-slate-300 dark:border-slate-700 rounded bg-white dark:bg-slate-900 text-slate-900 dark:text-white"
                />
              </div>

              <div className="p-3 rounded-lg border border-slate-200 dark:border-slate-800 bg-slate-50/50 dark:bg-slate-800/40">
                <span className="text-[11px] font-medium text-slate-600 dark:text-slate-400 block mb-1">
                  Feed Post ($)
                </span>
                <input
                  type="number"
                  value={ratePost}
                  onChange={e => setRatePost(Number(e.target.value))}
                  className="w-full px-2 py-1.5 text-xs font-mono tabular-nums border border-slate-300 dark:border-slate-700 rounded bg-white dark:bg-slate-900 text-slate-900 dark:text-white"
                />
              </div>

              <div className="p-3 rounded-lg border border-slate-200 dark:border-slate-800 bg-slate-50/50 dark:bg-slate-800/40">
                <span className="text-[11px] font-medium text-slate-600 dark:text-slate-400 block mb-1">
                  Story Frame ($)
                </span>
                <input
                  type="number"
                  value={rateStory}
                  onChange={e => setRateStory(Number(e.target.value))}
                  className="w-full px-2 py-1.5 text-xs font-mono tabular-nums border border-slate-300 dark:border-slate-700 rounded bg-white dark:bg-slate-900 text-slate-900 dark:text-white"
                />
              </div>
            </div>
          </div>
        )}

        <div className="flex justify-end">
          <button
            type="submit"
            disabled={saving}
            className="px-5 py-2.5 bg-indigo-600 hover:bg-indigo-700 text-white text-xs font-semibold rounded-lg shadow-sm flex items-center gap-2 transition-colors disabled:opacity-50"
          >
            <Save className="w-3.5 h-3.5" />
            <span>{saving ? 'Saving...' : 'Save Profile Changes'}</span>
          </button>
        </div>
      </form>
    </div>
  );
};
