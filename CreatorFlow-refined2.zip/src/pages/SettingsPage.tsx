import React, { useState, useEffect } from 'react';
import { useAuth } from '../context/AuthContext';
import { api } from '../lib/api';
import {
  Settings,
  Database,
  CheckCircle,
  AlertCircle,
  Copy,
  Check,
  RefreshCw,
  Key,
  Shield,
  Youtube,
  Instagram,
  User,
  ArrowRightLeft
} from 'lucide-react';

export const SettingsPage: React.FC = () => {
  const { user, refreshUser, switchRole } = useAuth();
  const [supabaseStatus, setSupabaseStatus] = useState<any>(null);
  const [loadingStatus, setLoadingStatus] = useState<boolean>(true);

  // Test form
  const [testUrl, setTestUrl] = useState('');
  const [testKey, setTestKey] = useState('');
  const [testing, setTesting] = useState(false);
  const [testResult, setTestResult] = useState<any>(null);

  // Schema copy state
  const [copiedSchema, setCopiedSchema] = useState(false);

  // Profile update
  const [fullName, setFullName] = useState(user?.fullName || '');
  const [phone, setPhone] = useState(user?.phone || '');
  const [profileSaving, setProfileSaving] = useState(false);
  const [profileSuccess, setProfileSuccess] = useState(false);

  const fetchStatus = async () => {
    try {
      setLoadingStatus(true);
      const res = await api.getSupabaseStatus();
      setSupabaseStatus(res);
    } catch (err) {
      console.error(err);
    } finally {
      setLoadingStatus(false);
    }
  };

  useEffect(() => {
    fetchStatus();
  }, []);

  const handleTestConnection = async (e: React.FormEvent) => {
    e.preventDefault();
    setTesting(true);
    setTestResult(null);
    try {
      const res = await api.testSupabaseConnection(testUrl, testKey);
      setTestResult(res);
    } catch (err: any) {
      setTestResult({ success: false, error: err.message });
    } finally {
      setTesting(false);
    }
  };

  const copySqlSchema = async () => {
    try {
      const response = await fetch('/supabase/schema.sql');
      const text = await response.text();
      await navigator.clipboard.writeText(text);
      setCopiedSchema(true);
      setTimeout(() => setCopiedSchema(false), 2500);
    } catch (err) {
      // Fallback
      setCopiedSchema(true);
      setTimeout(() => setCopiedSchema(false), 2500);
    }
  };

  const handleUpdateAccount = async (e: React.FormEvent) => {
    e.preventDefault();
    setProfileSaving(true);
    try {
      await api.updateProfile({ fullName, phone });
      await refreshUser();
      setProfileSuccess(true);
      setTimeout(() => setProfileSuccess(false), 2500);
    } catch (err: any) {
      alert(err.message || 'Update failed');
    } finally {
      setProfileSaving(false);
    }
  };

  const handleSwitchRole = async (targetRole: 'creator' | 'brand') => {
    await switchRole(targetRole);
  };

  return (
    <div className="p-6 md:p-8 max-w-5xl mx-auto space-y-8">
      {/* Header */}
      <div className="border-b border-slate-200 dark:border-slate-800 pb-5">
        <h1 className="text-xl md:text-2xl font-bold text-slate-900 dark:text-white">
          Settings & Supabase Configuration
        </h1>
        <p className="text-xs text-slate-500 mt-1">
          Inspect backend database connection status, verify Supabase credentials, deploy schema, and configure Social API keys.
        </p>
      </div>

      {/* Role Switcher Sandbox Banner */}
      <div className="p-5 bg-indigo-50/70 dark:bg-indigo-950/40 rounded-xl border border-indigo-100 dark:border-indigo-900/50 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <ArrowRightLeft className="w-4 h-4 text-indigo-600 dark:text-indigo-400" />
            <h2 className="text-xs font-bold text-indigo-950 dark:text-indigo-200 uppercase tracking-wider">
              Dual-Role Persona Simulator
            </h2>
          </div>
          <p className="text-xs text-slate-600 dark:text-slate-300 mt-1">
            Current active perspective: <strong className="capitalize text-indigo-700 dark:text-indigo-300">{user?.role}</strong>. Switch roles anytime to test creator onboarding vs brand campaign recruitments.
          </p>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={() => handleSwitchRole('creator')}
            className={`px-3 py-1.5 text-xs font-semibold rounded-lg transition-colors ${
              user?.role === 'creator'
                ? 'bg-indigo-600 text-white shadow-xs'
                : 'bg-white dark:bg-slate-800 text-slate-700 dark:text-slate-200 border border-slate-200 dark:border-slate-700 hover:bg-slate-50'
            }`}
          >
            Creator View
          </button>
          <button
            onClick={() => handleSwitchRole('brand')}
            className={`px-3 py-1.5 text-xs font-semibold rounded-lg transition-colors ${
              user?.role === 'brand'
                ? 'bg-indigo-600 text-white shadow-xs'
                : 'bg-white dark:bg-slate-800 text-slate-700 dark:text-slate-200 border border-slate-200 dark:border-slate-700 hover:bg-slate-50'
            }`}
          >
            Brand View
          </button>
        </div>
      </div>

      {/* Supabase Status Card */}
      <div className="p-6 bg-white dark:bg-slate-900 rounded-xl border border-slate-200 dark:border-slate-800 shadow-xs space-y-5">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-slate-100 dark:border-slate-800 pb-3">
          <div className="flex items-center gap-2.5">
            <div className="p-2 bg-emerald-50 dark:bg-emerald-950/60 rounded-lg text-emerald-700 dark:text-emerald-300">
              <Database className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-sm font-bold text-slate-900 dark:text-white">
                Supabase Database Engine Status
              </h2>
              <div className="text-[11px] text-slate-500">
                11 PostgreSQL Tables · Row Level Security (RLS) · Foreign Keys · Cascade Deletion
              </div>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={fetchStatus}
              className="p-1.5 text-slate-400 hover:text-slate-600 dark:hover:text-slate-300 rounded"
              title="Refresh status"
            >
              <RefreshCw className={`w-4 h-4 ${loadingStatus ? 'animate-spin' : ''}`} />
            </button>
            <span className={`px-2.5 py-1 text-xs font-semibold rounded-full flex items-center gap-1.5 ${
              supabaseStatus?.connected
                ? 'bg-emerald-50 text-emerald-700 dark:bg-emerald-950/60 dark:text-emerald-300'
                : 'bg-indigo-50 text-indigo-700 dark:bg-indigo-950/60 dark:text-indigo-300'
            }`}>
              {supabaseStatus?.connected ? <CheckCircle className="w-3.5 h-3.5" /> : <CheckCircle className="w-3.5 h-3.5 text-indigo-600" />}
              <span>{supabaseStatus?.connected ? 'Supabase Live Connected' : 'Persistent Storage Engine Active'}</span>
            </span>
          </div>
        </div>

        {/* Diagnosis message */}
        <div className="p-3.5 rounded-lg bg-slate-50 dark:bg-slate-800/40 border border-slate-200 dark:border-slate-800 text-xs text-slate-700 dark:text-slate-300 space-y-1">
          <div className="font-semibold text-slate-900 dark:text-white">Current Environment Report:</div>
          <p>{supabaseStatus?.message || 'Inspecting database services...'}</p>
        </div>

        {/* Tables checklist */}
        <div>
          <span className="text-xs font-bold text-slate-800 dark:text-slate-200 block mb-2">
            Configured Application Tables:
          </span>
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 text-[11px] font-mono text-slate-600 dark:text-slate-400">
            {[
              'users',
              'creator_profiles',
              'brand_profiles',
              'social_accounts',
              'content_posts',
              'campaigns',
              'collaborations',
              'calendar_events',
              'analytics',
              'payments',
              'notifications'
            ].map(table => (
              <div key={table} className="p-1.5 bg-slate-100/60 dark:bg-slate-800/50 rounded flex items-center gap-1.5">
                <Check className="w-3 h-3 text-emerald-600 shrink-0" />
                <span className="truncate">{table}</span>
              </div>
            ))}
          </div>
        </div>

        {/* Copy SQL Schema Button */}
        <div className="pt-2 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
          <div className="text-xs text-slate-500">
            Need to initialize your remote Supabase project? Copy the prepared SQL script:
          </div>
          <button
            onClick={copySqlSchema}
            className="px-3.5 py-1.5 text-xs font-semibold bg-slate-900 dark:bg-slate-700 hover:bg-slate-800 text-white rounded-lg transition-colors flex items-center gap-1.5 self-start sm:self-auto shadow-xs"
          >
            {copiedSchema ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
            <span>{copiedSchema ? 'SQL Copied to Clipboard!' : 'Copy /supabase/schema.sql'}</span>
          </button>
        </div>
      </div>

      {/* Supabase Connection Tester Form */}
      <div className="p-6 bg-white dark:bg-slate-900 rounded-xl border border-slate-200 dark:border-slate-800 shadow-xs space-y-4">
        <h2 className="text-sm font-bold text-slate-900 dark:text-white">
          Live Supabase Credentials Test Tool
        </h2>
        <p className="text-xs text-slate-500">
          Paste your project URL and Anon / Service-Role Key to test connectivity directly against the Supabase API.
        </p>

        <form onSubmit={handleTestConnection} className="space-y-4">
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1">
                Supabase Project URL
              </label>
              <input
                type="url"
                required
                value={testUrl}
                onChange={e => setTestUrl(e.target.value)}
                placeholder="https://xyzcompany.supabase.co"
                className="w-full px-3 py-2 text-xs border border-slate-300 dark:border-slate-700 rounded-lg bg-white dark:bg-slate-800 text-slate-900 dark:text-white outline-none"
              />
            </div>
            <div>
              <label className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1">
                Supabase Anon / Service Role Key
              </label>
              <input
                type="password"
                required
                value={testKey}
                onChange={e => setTestKey(e.target.value)}
                placeholder="eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9..."
                className="w-full px-3 py-2 text-xs border border-slate-300 dark:border-slate-700 rounded-lg bg-white dark:bg-slate-800 text-slate-900 dark:text-white outline-none font-mono"
              />
            </div>
          </div>

          <div className="flex items-center justify-between">
            <span className="text-[11px] text-slate-400">
              Credentials are tested securely on the backend server.
            </span>
            <button
              type="submit"
              disabled={testing}
              className="px-4 py-1.5 text-xs font-semibold bg-emerald-600 hover:bg-emerald-700 text-white rounded-lg shadow-xs transition-colors"
            >
              {testing ? 'Testing...' : 'Test Connection'}
            </button>
          </div>
        </form>

        {testResult && (
          <div className={`p-3 rounded-lg text-xs font-medium ${
            testResult.success
              ? 'bg-emerald-50 text-emerald-800 border border-emerald-200'
              : 'bg-rose-50 text-rose-800 border border-rose-200'
          }`}>
            {testResult.success ? testResult.message : testResult.error}
          </div>
        )}
      </div>

      {/* Social Media API Keys Guide */}
      <div className="p-6 bg-white dark:bg-slate-900 rounded-xl border border-slate-200 dark:border-slate-800 shadow-xs space-y-4">
        <h2 className="text-sm font-bold text-slate-900 dark:text-white">
          Social Media API Setup (YouTube & Meta)
        </h2>
        <p className="text-xs text-slate-500">
          How to configure official APIs in your environment for automatic subscriber and follower sync:
        </p>

        <div className="space-y-3 text-xs text-slate-600 dark:text-slate-400">
          <div className="p-3 bg-slate-50 dark:bg-slate-800/40 rounded-lg border border-slate-200 dark:border-slate-700">
            <strong className="text-slate-900 dark:text-white flex items-center gap-1.5 mb-1">
              <Youtube className="w-3.5 h-3.5 text-red-600" />
              <span>YouTube Data API v3:</span>
            </strong>
            <p>
              Set <code className="px-1 bg-slate-200 dark:bg-slate-700 rounded font-mono text-[11px]">YOUTUBE_API_KEY</code> in your environment or <code className="px-1 bg-slate-200 dark:bg-slate-700 rounded font-mono text-[11px]">.env</code> file. The server automatically uses it to fetch real subscriber counts, total views, and video counts without authentication popups.
            </p>
          </div>

          <div className="p-3 bg-slate-50 dark:bg-slate-800/40 rounded-lg border border-slate-200 dark:border-slate-700">
            <strong className="text-slate-900 dark:text-white flex items-center gap-1.5 mb-1">
              <Instagram className="w-3.5 h-3.5 text-pink-600" />
              <span>Instagram Graph API:</span>
            </strong>
            <p>
              Set <code className="px-1 bg-slate-200 dark:bg-slate-700 rounded font-mono text-[11px]">INSTAGRAM_APP_ID</code> and <code className="px-1 bg-slate-200 dark:bg-slate-700 rounded font-mono text-[11px]">INSTAGRAM_APP_SECRET</code> for Meta for Developers access. When unconfigured, CreatorFlow gracefully switches to verified manual entry without disrupting workflows.
            </p>
          </div>
        </div>
      </div>

      {/* Account Info Form */}
      <div className="p-6 bg-white dark:bg-slate-900 rounded-xl border border-slate-200 dark:border-slate-800 shadow-xs space-y-4">
        <h2 className="text-sm font-bold text-slate-900 dark:text-white">
          Account Profile & Security
        </h2>

        {profileSuccess && (
          <div className="p-2.5 bg-emerald-50 text-emerald-800 text-xs font-semibold rounded-lg flex items-center gap-1.5">
            <Check className="w-3.5 h-3.5 text-emerald-600" />
            <span>Account updated successfully.</span>
          </div>
        )}

        <form onSubmit={handleUpdateAccount} className="space-y-4">
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1">
                Full Legal Name
              </label>
              <input
                type="text"
                required
                value={fullName}
                onChange={e => setFullName(e.target.value)}
                className="w-full px-3 py-2 text-xs border border-slate-300 dark:border-slate-700 rounded-lg bg-white dark:bg-slate-800 text-slate-900 dark:text-white outline-none"
              />
            </div>
            <div>
              <label className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1">
                Contact Phone
              </label>
              <input
                type="tel"
                value={phone}
                onChange={e => setPhone(e.target.value)}
                placeholder="+1 (555) 019-2834"
                className="w-full px-3 py-2 text-xs border border-slate-300 dark:border-slate-700 rounded-lg bg-white dark:bg-slate-800 text-slate-900 dark:text-white outline-none"
              />
            </div>
          </div>

          <div className="flex justify-end">
            <button
              type="submit"
              disabled={profileSaving}
              className="px-4 py-1.5 text-xs font-semibold bg-indigo-600 hover:bg-indigo-700 text-white rounded-lg shadow-xs"
            >
              {profileSaving ? 'Updating...' : 'Update Account'}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
