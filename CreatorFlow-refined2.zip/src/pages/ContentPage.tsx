import React, { useState, useEffect } from 'react';
import { useAuth } from '../context/AuthContext';
import { api } from '../lib/api';
import { ContentPost, PostStatus, ContentType } from '../types';
import {
  Video,
  Plus,
  Search,
  Filter,
  Calendar,
  Eye,
  Heart,
  MessageSquare,
  Share2,
  Trash2,
  Edit2,
  CheckCircle,
  Clock,
  ExternalLink,
  X
} from 'lucide-react';

const STATUS_COLUMNS: { id: PostStatus; label: string }[] = [
  { id: 'idea', label: 'Ideas' },
  { id: 'scripting', label: 'Scripting' },
  { id: 'in_review', label: 'In Review' },
  { id: 'scheduled', label: 'Scheduled' },
  { id: 'published', label: 'Published' }
];

export const ContentPage: React.FC = () => {
  const { user } = useAuth();
  const [posts, setPosts] = useState<ContentPost[]>([]);
  const [loading, setLoading] = useState<boolean>(true);
  const [search, setSearch] = useState<string>('');
  const [selectedPlatform, setSelectedPlatform] = useState<string>('all');
  const [selectedStatus, setSelectedStatus] = useState<string>('all');

  // Modal state
  const [modalOpen, setModalOpen] = useState<boolean>(false);
  const [editingPost, setEditingPost] = useState<ContentPost | null>(null);

  // Form states
  const [title, setTitle] = useState('');
  const [platform, setPlatform] = useState<'youtube' | 'instagram' | 'tiktok' | 'twitter'>('youtube');
  const [contentType, setContentType] = useState<ContentType>('video');
  const [status, setStatus] = useState<PostStatus>('idea');
  const [scheduledFor, setScheduledFor] = useState('');
  const [caption, setCaption] = useState('');
  const [deliverablesNotes, setDeliverablesNotes] = useState('');
  const [views, setViews] = useState<number>(0);
  const [likes, setLikes] = useState<number>(0);
  const [comments, setComments] = useState<number>(0);
  const [shares, setShares] = useState<number>(0);

  const [saving, setSaving] = useState<boolean>(false);

  const fetchPosts = async () => {
    try {
      setLoading(true);
      const res = await api.getPosts();
      setPosts(res);
    } catch (err) {
      console.error('Error fetching posts:', err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchPosts();
  }, []);

  const openCreateModal = (presetStatus: PostStatus = 'idea') => {
    setEditingPost(null);
    setTitle('');
    setPlatform('youtube');
    setContentType('video');
    setStatus(presetStatus);
    setScheduledFor(new Date(Date.now() + 86400000 * 3).toISOString().slice(0, 16));
    setCaption('');
    setDeliverablesNotes('');
    setViews(0);
    setLikes(0);
    setComments(0);
    setShares(0);
    setModalOpen(true);
  };

  const openEditModal = (p: ContentPost) => {
    setEditingPost(p);
    setTitle(p.title);
    setPlatform(p.platform);
    setContentType(p.contentType);
    setStatus(p.status);
    setScheduledFor(p.scheduledFor ? p.scheduledFor.slice(0, 16) : '');
    setCaption(p.caption || '');
    setDeliverablesNotes(p.deliverablesNotes || '');
    setViews(p.views || 0);
    setLikes(p.likes || 0);
    setComments(p.comments || 0);
    setShares(p.shares || 0);
    setModalOpen(true);
  };

  const handleSave = async (e: React.FormEvent) => {
    e.preventDefault();
    setSaving(true);
    try {
      const payload = {
        title,
        platform,
        contentType,
        status,
        scheduledFor: scheduledFor ? new Date(scheduledFor).toISOString() : null,
        caption,
        deliverablesNotes,
        views: Number(views),
        likes: Number(likes),
        comments: Number(comments),
        shares: Number(shares)
      };

      if (editingPost) {
        await api.updatePost(editingPost.id, payload);
      } else {
        await api.createPost(payload);
      }

      setModalOpen(false);
      await fetchPosts();
    } catch (err: any) {
      alert(err.message || 'Failed to save post');
    } finally {
      setSaving(false);
    }
  };

  const handleDelete = async (id: string) => {
    if (!confirm('Are you sure you want to remove this content post?')) return;
    try {
      await api.deletePost(id);
      await fetchPosts();
    } catch (err: any) {
      alert(err.message || 'Failed to delete post');
    }
  };

  const handleQuickStatusChange = async (post: ContentPost, nextStatus: PostStatus) => {
    try {
      await api.updatePost(post.id, { status: nextStatus });
      await fetchPosts();
    } catch (err) {
      console.error(err);
    }
  };

  const filteredPosts = posts.filter(p => {
    const matchesSearch = p.title.toLowerCase().includes(search.toLowerCase()) || (p.caption || '').toLowerCase().includes(search.toLowerCase());
    const matchesPlatform = selectedPlatform === 'all' || p.platform === selectedPlatform;
    const matchesStatus = selectedStatus === 'all' || p.status === selectedStatus;
    return matchesSearch && matchesPlatform && matchesStatus;
  });

  return (
    <div className="p-6 md:p-8 max-w-7xl mx-auto space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-slate-200 dark:border-slate-800 pb-5">
        <div>
          <h1 className="text-xl md:text-2xl font-bold text-slate-900 dark:text-white">
            Content Management & Pipeline
          </h1>
          <p className="text-xs text-slate-500 mt-1">
            Organize production from initial concept to publication and monitor real engagement metrics.
          </p>
        </div>
        <button
          onClick={() => openCreateModal('idea')}
          className="px-3.5 py-2 text-xs font-semibold text-white bg-indigo-600 hover:bg-indigo-700 rounded-lg shadow-xs flex items-center gap-1.5 transition-colors self-start sm:self-auto"
        >
          <Plus className="w-3.5 h-3.5" />
          <span>New Content Item</span>
        </button>
      </div>

      {/* Filter and Search Bar */}
      <div className="flex flex-wrap items-center justify-between gap-3 bg-white dark:bg-slate-900 p-3 rounded-xl border border-slate-200 dark:border-slate-800">
        <div className="relative flex-1 min-w-[200px] max-w-md">
          <Search className="w-3.5 h-3.5 absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
          <input
            type="text"
            value={search}
            onChange={e => setSearch(e.target.value)}
            placeholder="Search content by title or caption..."
            className="w-full pl-9 pr-3 py-1.5 text-xs bg-slate-50 dark:bg-slate-800/60 border border-slate-200 dark:border-slate-700 rounded-lg text-slate-900 dark:text-white outline-none"
          />
        </div>

        <div className="flex items-center gap-2">
          {/* Platform filter tabs */}
          <div className="flex items-center gap-1 bg-slate-100 dark:bg-slate-800 p-1 rounded-lg">
            {['all', 'youtube', 'instagram', 'tiktok', 'twitter'].map(plat => (
              <button
                key={plat}
                onClick={() => setSelectedPlatform(plat)}
                className={`px-2.5 py-1 text-xs font-medium rounded-md capitalize transition-colors ${
                  selectedPlatform === plat
                    ? 'bg-white dark:bg-slate-700 text-slate-900 dark:text-white shadow-xs'
                    : 'text-slate-600 dark:text-slate-400 hover:text-slate-900'
                }`}
              >
                {plat === 'all' ? 'All Channels' : plat}
              </button>
            ))}
          </div>

          {/* Status selector */}
          <select
            value={selectedStatus}
            onChange={e => setSelectedStatus(e.target.value)}
            className="px-2.5 py-1.5 text-xs bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-lg text-slate-700 dark:text-slate-300 outline-none"
          >
            <option value="all">All Stages</option>
            <option value="idea">Ideas</option>
            <option value="scripting">Scripting</option>
            <option value="in_review">In Review</option>
            <option value="scheduled">Scheduled</option>
            <option value="published">Published</option>
          </select>
        </div>
      </div>

      {/* Kanban / Pipeline View */}
      {loading ? (
        <div className="grid grid-cols-1 md:grid-cols-5 gap-4 animate-pulse">
          {[1, 2, 3, 4, 5].map(i => (
            <div key={i} className="h-64 bg-slate-100 dark:bg-slate-800 rounded-xl" />
          ))}
        </div>
      ) : filteredPosts.length === 0 ? (
        <div className="p-12 text-center bg-white dark:bg-slate-900 rounded-xl border border-slate-200 dark:border-slate-800">
          <Video className="w-8 h-8 text-slate-400 mx-auto mb-3" />
          <h3 className="text-sm font-bold text-slate-900 dark:text-white">No content posts found</h3>
          <p className="text-xs text-slate-500 mt-1 max-w-sm mx-auto">
            {search || selectedPlatform !== 'all' || selectedStatus !== 'all'
              ? 'Try adjusting your search criteria or channel filters.'
              : 'Start your production pipeline by creating your first post or schedule deliverable.'}
          </p>
          <button
            onClick={() => openCreateModal('idea')}
            className="mt-4 px-3.5 py-1.5 text-xs font-semibold text-white bg-indigo-600 hover:bg-indigo-700 rounded-lg shadow-xs"
          >
            Create First Post
          </button>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-5 gap-4">
          {STATUS_COLUMNS.map(col => {
            const columnPosts = filteredPosts.filter(p => p.status === col.id);
            return (
              <div
                key={col.id}
                className="bg-slate-100/70 dark:bg-slate-900/60 rounded-xl p-3 border border-slate-200 dark:border-slate-800 flex flex-col min-h-[400px]"
              >
                {/* Column Header */}
                <div className="flex items-center justify-between pb-2 mb-2 border-b border-slate-200 dark:border-slate-800">
                  <div className="flex items-center gap-1.5">
                    <span className="text-xs font-bold text-slate-800 dark:text-slate-200">{col.label}</span>
                    <span className="text-[11px] font-mono text-slate-400 font-semibold">({columnPosts.length})</span>
                  </div>
                  <button
                    onClick={() => openCreateModal(col.id)}
                    className="p-1 text-slate-400 hover:text-indigo-600 rounded"
                    title={`Add new ${col.label}`}
                  >
                    <Plus className="w-3.5 h-3.5" />
                  </button>
                </div>

                {/* Cards */}
                <div className="space-y-2.5 flex-1 overflow-y-auto">
                  {columnPosts.map(post => (
                    <div
                      key={post.id}
                      className="p-3 bg-white dark:bg-slate-800 rounded-lg border border-slate-200 dark:border-slate-700 shadow-xs hover:border-slate-300 dark:hover:border-slate-600 transition-all space-y-2"
                    >
                      <div className="flex items-start justify-between gap-1">
                        <span className="text-xs font-semibold text-slate-900 dark:text-white line-clamp-2">
                          {post.title}
                        </span>
                        <div className="flex items-center gap-1 shrink-0">
                          <button
                            onClick={() => openEditModal(post)}
                            className="p-1 text-slate-400 hover:text-slate-600 dark:hover:text-slate-300 rounded"
                            title="Edit"
                          >
                            <Edit2 className="w-3 h-3" />
                          </button>
                          <button
                            onClick={() => handleDelete(post.id)}
                            className="p-1 text-slate-400 hover:text-rose-600 rounded"
                            title="Delete"
                          >
                            <Trash2 className="w-3 h-3" />
                          </button>
                        </div>
                      </div>

                      <div className="flex items-center gap-2 text-[11px] text-slate-500">
                        <span className="capitalize font-medium text-indigo-600 dark:text-indigo-400">{post.platform}</span>
                        <span aria-hidden="true">·</span>
                        <span className="capitalize">{post.contentType}</span>
                      </div>

                      {post.caption && (
                        <p className="text-[11px] text-slate-600 dark:text-slate-400 line-clamp-2 italic">
                          "{post.caption}"
                        </p>
                      )}

                      {post.scheduledFor && (
                        <div className="flex items-center gap-1 text-[11px] text-amber-600 dark:text-amber-400 font-mono">
                          <Clock className="w-3 h-3" />
                          <span>{new Date(post.scheduledFor).toLocaleDateString()}</span>
                        </div>
                      )}

                      {/* Performance row if published */}
                      {post.status === 'published' && (
                        <div className="pt-2 border-t border-slate-100 dark:border-slate-700/60 grid grid-cols-3 gap-1 text-center font-mono text-[10px] tabular-nums text-slate-600 dark:text-slate-400">
                          <div>
                            <div className="font-bold text-slate-900 dark:text-white">{post.views.toLocaleString()}</div>
                            <div className="text-[9px] text-slate-400">Views</div>
                          </div>
                          <div>
                            <div className="font-bold text-slate-900 dark:text-white">{post.likes.toLocaleString()}</div>
                            <div className="text-[9px] text-slate-400">Likes</div>
                          </div>
                          <div>
                            <div className="font-bold text-slate-900 dark:text-white">{post.comments.toLocaleString()}</div>
                            <div className="text-[9px] text-slate-400">Cmts</div>
                          </div>
                        </div>
                      )}

                      {/* Advance Stage button */}
                      <div className="pt-1.5 flex items-center justify-between">
                        {post.status !== 'published' ? (
                          <button
                            onClick={() => {
                              const currentIndex = STATUS_COLUMNS.findIndex(s => s.id === post.status);
                              if (currentIndex < STATUS_COLUMNS.length - 1) {
                                handleQuickStatusChange(post, STATUS_COLUMNS[currentIndex + 1].id);
                              }
                            }}
                            className="text-[10px] font-semibold text-indigo-600 hover:text-indigo-700 flex items-center gap-1"
                          >
                            <span>Move to {STATUS_COLUMNS[STATUS_COLUMNS.findIndex(s => s.id === post.status) + 1]?.label}</span>
                            <span>→</span>
                          </button>
                        ) : (
                          <span className="text-[10px] text-emerald-600 font-medium flex items-center gap-1">
                            <CheckCircle className="w-3 h-3" />
                            <span>Live</span>
                          </span>
                        )}
                      </div>
                    </div>
                  ))}

                  {columnPosts.length === 0 && (
                    <div className="p-4 text-center text-[11px] text-slate-400 italic">
                      Empty stage
                    </div>
                  )}
                </div>
              </div>
            );
          })}
        </div>
      )}

      {/* Create / Edit Modal */}
      {modalOpen && (
        <div className="fixed inset-0 bg-slate-900/50 backdrop-blur-xs flex items-center justify-center p-4 z-50">
          <div className="bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 max-w-lg w-full p-6 shadow-xl max-h-[90vh] overflow-y-auto">
            <div className="flex items-center justify-between pb-3 border-b border-slate-200 dark:border-slate-800">
              <h2 className="text-sm font-bold text-slate-900 dark:text-white">
                {editingPost ? 'Edit Content Item' : 'New Content Pipeline Item'}
              </h2>
              <button onClick={() => setModalOpen(false)} className="text-slate-400 hover:text-slate-600">
                <X className="w-4 h-4" />
              </button>
            </div>

            <form onSubmit={handleSave} className="mt-4 space-y-4">
              <div>
                <label className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1">
                  Title / Working Topic
                </label>
                <input
                  type="text"
                  required
                  value={title}
                  onChange={e => setTitle(e.target.value)}
                  placeholder="e.g. My Ultimate 2026 Studio Desk Setup Tour"
                  className="w-full px-3 py-2 text-xs border border-slate-300 dark:border-slate-700 rounded-lg bg-white dark:bg-slate-800 text-slate-900 dark:text-white outline-none"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1">
                    Publishing Channel
                  </label>
                  <select
                    value={platform}
                    onChange={e => setPlatform(e.target.value as any)}
                    className="w-full px-3 py-2 text-xs border border-slate-300 dark:border-slate-700 rounded-lg bg-white dark:bg-slate-800 text-slate-900 dark:text-white outline-none capitalize"
                  >
                    <option value="youtube">YouTube</option>
                    <option value="instagram">Instagram</option>
                    <option value="tiktok">TikTok</option>
                    <option value="twitter">X / Twitter</option>
                  </select>
                </div>
                <div>
                  <label className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1">
                    Format
                  </label>
                  <select
                    value={contentType}
                    onChange={e => setContentType(e.target.value as any)}
                    className="w-full px-3 py-2 text-xs border border-slate-300 dark:border-slate-700 rounded-lg bg-white dark:bg-slate-800 text-slate-900 dark:text-white outline-none capitalize"
                  >
                    <option value="video">Long-Form Video</option>
                    <option value="reel">Reel</option>
                    <option value="short">Short</option>
                    <option value="post">Feed Post</option>
                    <option value="carousel">Carousel</option>
                    <option value="story">Story</option>
                  </select>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1">
                    Pipeline Stage
                  </label>
                  <select
                    value={status}
                    onChange={e => setStatus(e.target.value as any)}
                    className="w-full px-3 py-2 text-xs border border-slate-300 dark:border-slate-700 rounded-lg bg-white dark:bg-slate-800 text-slate-900 dark:text-white outline-none"
                  >
                    <option value="idea">Idea</option>
                    <option value="scripting">Scripting</option>
                    <option value="in_review">In Review</option>
                    <option value="scheduled">Scheduled</option>
                    <option value="published">Published</option>
                  </select>
                </div>
                <div>
                  <label className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1">
                    Target Publish Date & Time
                  </label>
                  <input
                    type="datetime-local"
                    value={scheduledFor}
                    onChange={e => setScheduledFor(e.target.value)}
                    className="w-full px-3 py-1.5 text-xs border border-slate-300 dark:border-slate-700 rounded-lg bg-white dark:bg-slate-800 text-slate-900 dark:text-white outline-none font-mono"
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1">
                  Draft Caption / Outline
                </label>
                <textarea
                  rows={3}
                  value={caption}
                  onChange={e => setCaption(e.target.value)}
                  placeholder="Draft copy, hooks, hashtags, and sponsor callouts..."
                  className="w-full px-3 py-2 text-xs border border-slate-300 dark:border-slate-700 rounded-lg bg-white dark:bg-slate-800 text-slate-900 dark:text-white outline-none"
                />
              </div>

              {/* Performance Metrics Tracker */}
              <div className="p-3 bg-slate-50 dark:bg-slate-800/40 rounded-xl border border-slate-200 dark:border-slate-700">
                <span className="text-xs font-semibold text-slate-700 dark:text-slate-300 block mb-2">
                  Verified Post Performance (Logged Post-Publish)
                </span>
                <div className="grid grid-cols-4 gap-2">
                  <div>
                    <label className="block text-[10px] text-slate-500 mb-0.5">Views</label>
                    <input
                      type="number"
                      value={views}
                      onChange={e => setViews(Number(e.target.value))}
                      className="w-full px-2 py-1 text-xs font-mono tabular-nums border border-slate-300 dark:border-slate-700 rounded bg-white dark:bg-slate-900 text-slate-900 dark:text-white"
                    />
                  </div>
                  <div>
                    <label className="block text-[10px] text-slate-500 mb-0.5">Likes</label>
                    <input
                      type="number"
                      value={likes}
                      onChange={e => setLikes(Number(e.target.value))}
                      className="w-full px-2 py-1 text-xs font-mono tabular-nums border border-slate-300 dark:border-slate-700 rounded bg-white dark:bg-slate-900 text-slate-900 dark:text-white"
                    />
                  </div>
                  <div>
                    <label className="block text-[10px] text-slate-500 mb-0.5">Comments</label>
                    <input
                      type="number"
                      value={comments}
                      onChange={e => setComments(Number(e.target.value))}
                      className="w-full px-2 py-1 text-xs font-mono tabular-nums border border-slate-300 dark:border-slate-700 rounded bg-white dark:bg-slate-900 text-slate-900 dark:text-white"
                    />
                  </div>
                  <div>
                    <label className="block text-[10px] text-slate-500 mb-0.5">Shares</label>
                    <input
                      type="number"
                      value={shares}
                      onChange={e => setShares(Number(e.target.value))}
                      className="w-full px-2 py-1 text-xs font-mono tabular-nums border border-slate-300 dark:border-slate-700 rounded bg-white dark:bg-slate-900 text-slate-900 dark:text-white"
                    />
                  </div>
                </div>
              </div>

              <div className="flex justify-end gap-2 pt-3 border-t border-slate-200 dark:border-slate-800">
                <button
                  type="button"
                  onClick={() => setModalOpen(false)}
                  className="px-3.5 py-1.5 text-xs font-medium border border-slate-300 dark:border-slate-700 text-slate-700 dark:text-slate-300 rounded-lg hover:bg-slate-50"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={saving}
                  className="px-4 py-1.5 text-xs font-semibold bg-indigo-600 hover:bg-indigo-700 text-white rounded-lg shadow-xs"
                >
                  {saving ? 'Saving...' : editingPost ? 'Update Post' : 'Save to Pipeline'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
