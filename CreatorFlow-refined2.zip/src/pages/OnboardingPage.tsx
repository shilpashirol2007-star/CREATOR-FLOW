import React, { useState } from 'react';
import { useAuth } from '../context/AuthContext';
import { api } from '../lib/api';
import { Check, ArrowRight, User, Globe, MapPin, Youtube, Instagram, DollarSign, Sparkles } from 'lucide-react';

const NICHES = [
  'Tech & Software',
  'Lifestyle & Vlogging',
  'Gaming & Esports',
  'Fitness & Wellness',
  'Beauty & Fashion',
  'Finance & Crypto',
  'Food & Cooking',
  'Travel & Adventure',
  'Education & Science',
  'Photography & Design'
];

const CATEGORIES = [
  'Product Reviews',
  'Tutorials & How-To',
  'Unboxing',
  'Day in the Life',
  'Podcast & Interviews',
  'Short Skits & Reels',
  'Deep Dives & Essays',
  'Livestreams'
];

export const OnboardingPage: React.FC<{ onComplete: () => void }> = ({ onComplete }) => {
  const { user, refreshUser } = useAuth();
  const isCreator = user?.role === 'creator';

  const [step, setStep] = useState<number>(1);
  const [loading, setLoading] = useState<boolean>(false);
  const [error, setError] = useState<string | null>(null);

  // Creator state
  const [fullName, setFullName] = useState(user?.fullName || '');
  const [avatarUrl, setAvatarUrl] = useState(user?.avatarUrl || '/src/assets/images/creator_avatar_female_1793577526256.jpg');
  const [phone, setPhone] = useState(user?.phone || '');
  const [bio, setBio] = useState('');
  const [niche, setNiche] = useState(NICHES[0]);
  const [location, setLocation] = useState('');
  const [website, setWebsite] = useState('');
  const [primaryPlatform, setPrimaryPlatform] = useState<'youtube' | 'instagram' | 'tiktok' | 'twitter'>('youtube');
  const [selectedCategories, setSelectedCategories] = useState<string[]>(['Product Reviews', 'Tutorials & How-To']);

  // Social account inputs
  const [youtubeHandle, setYoutubeHandle] = useState('');
  const [youtubeSubs, setYoutubeSubs] = useState<number | ''>('');
  const [youtubeViews, setYoutubeViews] = useState<number | ''>('');
  const [youtubeConnected, setYoutubeConnected] = useState<boolean>(false);

  const [instaHandle, setInstaHandle] = useState('');
  const [instaFollowers, setInstaFollowers] = useState<number | ''>('');
  const [instaEngagement, setInstaEngagement] = useState<number | ''>('');

  // Collaboration rates
  const [ratePost, setRatePost] = useState<number | ''>(250);
  const [rateVideo, setRateVideo] = useState<number | ''>(850);
  const [rateReel, setRateReel] = useState<number | ''>(400);
  const [rateStory, setRateStory] = useState<number | ''>(150);
  const [acceptGifted, setAcceptGifted] = useState<boolean>(false);
  const [acceptRevShare, setAcceptRevShare] = useState<boolean>(true);

  // Brand state
  const [companyName, setCompanyName] = useState(user?.fullName || '');
  const [industry, setIndustry] = useState('E-Commerce & DTC');
  const [brandDesc, setBrandDesc] = useState('');
  const [budgetTier, setBudgetTier] = useState('growth');
  const [targetAudience, setTargetAudience] = useState('');

  const toggleCategory = (cat: string) => {
    if (selectedCategories.includes(cat)) {
      setSelectedCategories(selectedCategories.filter(c => c !== cat));
    } else {
      setSelectedCategories([...selectedCategories, cat]);
    }
  };

  const handleFinish = async () => {
    setLoading(true);
    setError(null);

    try {
      if (isCreator) {
        const socials = [];
        if (youtubeHandle) {
          socials.push({
            platform: 'youtube',
            handle: youtubeHandle,
            displayName: youtubeHandle,
            followerCount: Number(youtubeSubs) || 0,
            subscribers: Number(youtubeSubs) || 0,
            totalViews: Number(youtubeViews) || 0,
            engagementRate: 3.8,
            apiStatus: youtubeConnected ? 'connected' : 'manual'
          });
        }
        if (instaHandle) {
          socials.push({
            platform: 'instagram',
            handle: instaHandle,
            displayName: instaHandle,
            followerCount: Number(instaFollowers) || 0,
            subscribers: Number(instaFollowers) || 0,
            totalViews: 0,
            engagementRate: Number(instaEngagement) || 2.5,
            apiStatus: 'manual'
          });
        }

        await api.submitOnboarding({
          fullName,
          avatarUrl,
          phone,
          bio,
          niche,
          location,
          website,
          primaryPlatform,
          contentCategories: selectedCategories,
          ratePost: Number(ratePost) || 0,
          rateVideo: Number(rateVideo) || 0,
          rateReel: Number(rateReel) || 0,
          rateStory: Number(rateStory) || 0,
          acceptGifted,
          acceptRevShare,
          socials
        });
      } else {
        await api.submitOnboarding({
          fullName,
          avatarUrl: avatarUrl || '/src/assets/images/brand_partner_avatar_1793577525807.jpg',
          phone,
          companyName,
          industry,
          website,
          description: brandDesc,
          budgetTier,
          targetAudience
        });
      }

      await refreshUser();
      onComplete();
    } catch (err: any) {
      setError(err.message || 'Failed to complete onboarding');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-slate-50 dark:bg-slate-950 py-10 px-4 sm:px-6">
      <div className="max-w-2xl mx-auto">
        {/* Header */}
        <div className="text-center mb-8">
          <div className="w-10 h-10 rounded-xl bg-indigo-600 text-white flex items-center justify-center font-bold text-base mx-auto mb-3 shadow-xs">
            CF
          </div>
          <h1 className="text-2xl font-bold text-slate-900 dark:text-white">
            {isCreator ? 'Complete Creator Profile' : 'Configure Brand Workspace'}
          </h1>
          <p className="text-xs text-slate-500 mt-1">
            {isCreator
              ? 'Connect your channels, establish your rate card, and set up your verified portfolio'
              : 'Set up your company profile and specify target demographics for creator partnerships'}
          </p>

          {/* Stepper */}
          <div className="flex items-center justify-center gap-3 mt-6">
            {[1, 2, 3, 4].map(s => (
              <div key={s} className="flex items-center gap-1.5">
                <div
                  className={`w-7 h-7 rounded-full text-xs font-semibold flex items-center justify-center transition-colors ${
                    step === s
                      ? 'bg-indigo-600 text-white shadow-xs'
                      : step > s
                      ? 'bg-emerald-600 text-white'
                      : 'bg-slate-200 dark:bg-slate-800 text-slate-600 dark:text-slate-400'
                  }`}
                >
                  {step > s ? <Check className="w-3.5 h-3.5" /> : s}
                </div>
                {s < 4 && <div className="w-8 h-0.5 bg-slate-200 dark:bg-slate-800" />}
              </div>
            ))}
          </div>
        </div>

        {error && (
          <div className="mb-6 p-3 rounded-lg bg-rose-50 border border-rose-200 text-xs text-rose-700 font-medium">
            {error}
          </div>
        )}

        <div className="bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 p-6 sm:p-8 shadow-xs">
          {/* STEP 1: Personal & Basic Info */}
          {step === 1 && (
            <div className="space-y-4">
              <h2 className="text-sm font-bold text-slate-900 dark:text-white border-b border-slate-100 dark:border-slate-800 pb-2">
                1. Basic Information & Contact
              </h2>

              <div>
                <label className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1">
                  Full Name / Legal Name
                </label>
                <input
                  type="text"
                  value={fullName}
                  onChange={e => setFullName(e.target.value)}
                  className="w-full px-3 py-2 text-xs border border-slate-300 dark:border-slate-700 rounded-lg bg-white dark:bg-slate-800 text-slate-900 dark:text-white focus:ring-2 focus:ring-indigo-500 outline-none"
                  placeholder="e.g. Elena Vance"
                />
              </div>

              <div>
                <label className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1">
                  Profile Avatar / Headshot
                </label>
                <div className="flex items-center gap-4">
                  <img
                    src={avatarUrl}
                    alt="Preview"
                    referrerPolicy="no-referrer"
                    className="w-14 h-14 rounded-full object-cover border-2 border-indigo-500 shrink-0"
                  />
                  <div className="flex-1 space-y-2">
                    <div className="text-[11px] text-slate-500">Pick from high-res studio portraits or enter custom image URL:</div>
                    <div className="flex gap-2">
                      <button
                        type="button"
                        onClick={() => setAvatarUrl('/src/assets/images/creator_avatar_female_1793577526256.jpg')}
                        className="px-2 py-1 text-[11px] bg-slate-100 hover:bg-slate-200 dark:bg-slate-800 rounded font-medium text-slate-700 dark:text-slate-300"
                      >
                        Female Avatar
                      </button>
                      <button
                        type="button"
                        onClick={() => setAvatarUrl('/src/assets/images/creator_avatar_male_1793577526008.jpg')}
                        className="px-2 py-1 text-[11px] bg-slate-100 hover:bg-slate-200 dark:bg-slate-800 rounded font-medium text-slate-700 dark:text-slate-300"
                      >
                        Male Avatar
                      </button>
                    </div>
                  </div>
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1">
                    Contact Phone (Optional)
                  </label>
                  <input
                    type="tel"
                    value={phone}
                    onChange={e => setPhone(e.target.value)}
                    className="w-full px-3 py-2 text-xs border border-slate-300 dark:border-slate-700 rounded-lg bg-white dark:bg-slate-800 text-slate-900 dark:text-white focus:ring-2 focus:ring-indigo-500 outline-none"
                    placeholder="+1 (555) 019-2834"
                  />
                </div>
                <div>
                  <label className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1">
                    Location / Timezone
                  </label>
                  <input
                    type="text"
                    value={location}
                    onChange={e => setLocation(e.target.value)}
                    className="w-full px-3 py-2 text-xs border border-slate-300 dark:border-slate-700 rounded-lg bg-white dark:bg-slate-800 text-slate-900 dark:text-white focus:ring-2 focus:ring-indigo-500 outline-none"
                    placeholder="e.g. Los Angeles, CA (PST)"
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1">
                  Bio / Brand Statement
                </label>
                <textarea
                  rows={3}
                  value={bio}
                  onChange={e => setBio(e.target.value)}
                  className="w-full px-3 py-2 text-xs border border-slate-300 dark:border-slate-700 rounded-lg bg-white dark:bg-slate-800 text-slate-900 dark:text-white focus:ring-2 focus:ring-indigo-500 outline-none"
                  placeholder="Tell brands about your mission, aesthetic, and audience demographics..."
                />
              </div>

              <div className="flex justify-end pt-4">
                <button
                  type="button"
                  onClick={() => setStep(2)}
                  className="px-4 py-2 bg-indigo-600 hover:bg-indigo-700 text-white text-xs font-semibold rounded-lg flex items-center gap-1.5 transition-colors"
                >
                  <span>Continue to Step 2</span>
                  <ArrowRight className="w-3.5 h-3.5" />
                </button>
              </div>
            </div>
          )}

          {/* STEP 2: Niche & Content Categories */}
          {step === 2 && (
            <div className="space-y-4">
              <h2 className="text-sm font-bold text-slate-900 dark:text-white border-b border-slate-100 dark:border-slate-800 pb-2">
                2. Niche & Content Categories
              </h2>

              <div>
                <label className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1">
                  Primary Creator Niche
                </label>
                <select
                  value={niche}
                  onChange={e => setNiche(e.target.value)}
                  className="w-full px-3 py-2 text-xs border border-slate-300 dark:border-slate-700 rounded-lg bg-white dark:bg-slate-800 text-slate-900 dark:text-white focus:ring-2 focus:ring-indigo-500 outline-none"
                >
                  {NICHES.map(n => (
                    <option key={n} value={n}>{n}</option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1">
                  Primary Publishing Platform
                </label>
                <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
                  {[
                    { id: 'youtube', label: 'YouTube' },
                    { id: 'instagram', label: 'Instagram' },
                    { id: 'tiktok', label: 'TikTok' },
                    { id: 'twitter', label: 'X / Twitter' }
                  ].map(p => (
                    <button
                      key={p.id}
                      type="button"
                      onClick={() => setPrimaryPlatform(p.id as any)}
                      className={`p-2.5 rounded-lg border text-xs font-semibold text-center transition-all ${
                        primaryPlatform === p.id
                          ? 'border-indigo-600 bg-indigo-50/60 dark:bg-indigo-950/40 text-indigo-700 dark:text-indigo-300'
                          : 'border-slate-200 dark:border-slate-800 text-slate-600 dark:text-slate-400 hover:border-slate-300'
                      }`}
                    >
                      {p.label}
                    </button>
                  ))}
                </div>
              </div>

              <div>
                <label className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-2">
                  Content Deliverable Categories (Select all that apply)
                </label>
                <div className="grid grid-cols-2 sm:grid-cols-3 gap-2">
                  {CATEGORIES.map(cat => {
                    const active = selectedCategories.includes(cat);
                    return (
                      <button
                        key={cat}
                        type="button"
                        onClick={() => toggleCategory(cat)}
                        className={`p-2 rounded-lg border text-left text-xs transition-colors flex items-center justify-between ${
                          active
                            ? 'border-indigo-600 bg-indigo-50 dark:bg-indigo-950/40 text-indigo-900 dark:text-indigo-300 font-medium'
                            : 'border-slate-200 dark:border-slate-800 text-slate-600 dark:text-slate-400 hover:bg-slate-50'
                        }`}
                      >
                        <span>{cat}</span>
                        {active && <Check className="w-3.5 h-3.5 text-indigo-600 shrink-0" />}
                      </button>
                    );
                  })}
                </div>
              </div>

              <div className="flex justify-between pt-4">
                <button
                  type="button"
                  onClick={() => setStep(1)}
                  className="px-4 py-2 border border-slate-300 dark:border-slate-700 text-slate-700 dark:text-slate-300 text-xs font-semibold rounded-lg hover:bg-slate-50"
                >
                  Back
                </button>
                <button
                  type="button"
                  onClick={() => setStep(3)}
                  className="px-4 py-2 bg-indigo-600 hover:bg-indigo-700 text-white text-xs font-semibold rounded-lg flex items-center gap-1.5 transition-colors"
                >
                  <span>Continue to Step 3</span>
                  <ArrowRight className="w-3.5 h-3.5" />
                </button>
              </div>
            </div>
          )}

          {/* STEP 3: Social Media Accounts & Real Metrics */}
          {step === 3 && (
            <div className="space-y-5">
              <div>
                <h2 className="text-sm font-bold text-slate-900 dark:text-white">
                  3. Social Media Account Connections & Baseline Metrics
                </h2>
                <p className="text-xs text-slate-500 mt-0.5">
                  Connect official accounts or enter verified metrics. No hardcoded or fake vanity stats will ever be displayed.
                </p>
              </div>

              {/* YouTube Card */}
              <div className="p-4 rounded-xl border border-slate-200 dark:border-slate-800 bg-slate-50/50 dark:bg-slate-800/40 space-y-3">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <Youtube className="w-5 h-5 text-red-600" />
                    <span className="text-xs font-bold text-slate-900 dark:text-white">YouTube Channel</span>
                  </div>
                  <span className="text-[11px] text-slate-500">Official API / Verified Manual</span>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                  <div>
                    <label className="block text-[11px] font-medium text-slate-600 dark:text-slate-400 mb-1">
                      Channel Handle / URL
                    </label>
                    <input
                      type="text"
                      value={youtubeHandle}
                      onChange={e => setYoutubeHandle(e.target.value)}
                      placeholder="@elenavance"
                      className="w-full px-3 py-1.5 text-xs border border-slate-300 dark:border-slate-700 rounded-lg bg-white dark:bg-slate-900 text-slate-900 dark:text-white outline-none"
                    />
                  </div>
                  <div>
                    <label className="block text-[11px] font-medium text-slate-600 dark:text-slate-400 mb-1">
                      Subscriber Count
                    </label>
                    <input
                      type="number"
                      value={youtubeSubs}
                      onChange={e => setYoutubeSubs(e.target.value === '' ? '' : Number(e.target.value))}
                      placeholder="e.g. 48500"
                      className="w-full px-3 py-1.5 text-xs font-mono tabular-nums border border-slate-300 dark:border-slate-700 rounded-lg bg-white dark:bg-slate-900 text-slate-900 dark:text-white outline-none"
                    />
                  </div>
                  <div>
                    <label className="block text-[11px] font-medium text-slate-600 dark:text-slate-400 mb-1">
                      Lifetime Views
                    </label>
                    <input
                      type="number"
                      value={youtubeViews}
                      onChange={e => setYoutubeViews(e.target.value === '' ? '' : Number(e.target.value))}
                      placeholder="e.g. 2400000"
                      className="w-full px-3 py-1.5 text-xs font-mono tabular-nums border border-slate-300 dark:border-slate-700 rounded-lg bg-white dark:bg-slate-900 text-slate-900 dark:text-white outline-none"
                    />
                  </div>
                </div>
              </div>

              {/* Instagram Card */}
              <div className="p-4 rounded-xl border border-slate-200 dark:border-slate-800 bg-slate-50/50 dark:bg-slate-800/40 space-y-3">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <Instagram className="w-5 h-5 text-pink-600" />
                    <span className="text-xs font-bold text-slate-900 dark:text-white">Instagram Account</span>
                  </div>
                  <span className="text-[11px] text-slate-500">Graph API / Verified Manual</span>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                  <div>
                    <label className="block text-[11px] font-medium text-slate-600 dark:text-slate-400 mb-1">
                      Instagram Handle
                    </label>
                    <input
                      type="text"
                      value={instaHandle}
                      onChange={e => setInstaHandle(e.target.value)}
                      placeholder="@elena.creates"
                      className="w-full px-3 py-1.5 text-xs border border-slate-300 dark:border-slate-700 rounded-lg bg-white dark:bg-slate-900 text-slate-900 dark:text-white outline-none"
                    />
                  </div>
                  <div>
                    <label className="block text-[11px] font-medium text-slate-600 dark:text-slate-400 mb-1">
                      Followers
                    </label>
                    <input
                      type="number"
                      value={instaFollowers}
                      onChange={e => setInstaFollowers(e.target.value === '' ? '' : Number(e.target.value))}
                      placeholder="e.g. 32000"
                      className="w-full px-3 py-1.5 text-xs font-mono tabular-nums border border-slate-300 dark:border-slate-700 rounded-lg bg-white dark:bg-slate-900 text-slate-900 dark:text-white outline-none"
                    />
                  </div>
                  <div>
                    <label className="block text-[11px] font-medium text-slate-600 dark:text-slate-400 mb-1">
                      Avg. Engagement (%)
                    </label>
                    <input
                      type="number"
                      step="0.1"
                      value={instaEngagement}
                      onChange={e => setInstaEngagement(e.target.value === '' ? '' : Number(e.target.value))}
                      placeholder="e.g. 3.4"
                      className="w-full px-3 py-1.5 text-xs font-mono tabular-nums border border-slate-300 dark:border-slate-700 rounded-lg bg-white dark:bg-slate-900 text-slate-900 dark:text-white outline-none"
                    />
                  </div>
                </div>
              </div>

              <div className="flex justify-between pt-4">
                <button
                  type="button"
                  onClick={() => setStep(2)}
                  className="px-4 py-2 border border-slate-300 dark:border-slate-700 text-slate-700 dark:text-slate-300 text-xs font-semibold rounded-lg hover:bg-slate-50"
                >
                  Back
                </button>
                <button
                  type="button"
                  onClick={() => setStep(4)}
                  className="px-4 py-2 bg-indigo-600 hover:bg-indigo-700 text-white text-xs font-semibold rounded-lg flex items-center gap-1.5 transition-colors"
                >
                  <span>Continue to Rates</span>
                  <ArrowRight className="w-3.5 h-3.5" />
                </button>
              </div>
            </div>
          )}

          {/* STEP 4: Collaboration Preferences & Pricing */}
          {step === 4 && (
            <div className="space-y-5">
              <div>
                <h2 className="text-sm font-bold text-slate-900 dark:text-white">
                  4. Commercial Rate Card & Collaboration Terms
                </h2>
                <p className="text-xs text-slate-500 mt-0.5">
                  Set baseline quotes for brand deals. You can negotiate on a per-campaign basis later.
                </p>
              </div>

              <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
                <div className="p-3 bg-slate-50 dark:bg-slate-800/50 rounded-xl border border-slate-200 dark:border-slate-700">
                  <label className="block text-[11px] font-medium text-slate-600 dark:text-slate-400 mb-1">
                    Dedicated Video ($)
                  </label>
                  <input
                    type="number"
                    value={rateVideo}
                    onChange={e => setRateVideo(e.target.value === '' ? '' : Number(e.target.value))}
                    className="w-full px-2.5 py-1.5 text-xs font-mono tabular-nums border border-slate-300 dark:border-slate-700 rounded-md bg-white dark:bg-slate-900 text-slate-900 dark:text-white"
                  />
                </div>
                <div className="p-3 bg-slate-50 dark:bg-slate-800/50 rounded-xl border border-slate-200 dark:border-slate-700">
                  <label className="block text-[11px] font-medium text-slate-600 dark:text-slate-400 mb-1">
                    Reel / Short ($)
                  </label>
                  <input
                    type="number"
                    value={rateReel}
                    onChange={e => setRateReel(e.target.value === '' ? '' : Number(e.target.value))}
                    className="w-full px-2.5 py-1.5 text-xs font-mono tabular-nums border border-slate-300 dark:border-slate-700 rounded-md bg-white dark:bg-slate-900 text-slate-900 dark:text-white"
                  />
                </div>
                <div className="p-3 bg-slate-50 dark:bg-slate-800/50 rounded-xl border border-slate-200 dark:border-slate-700">
                  <label className="block text-[11px] font-medium text-slate-600 dark:text-slate-400 mb-1">
                    Static Feed Post ($)
                  </label>
                  <input
                    type="number"
                    value={ratePost}
                    onChange={e => setRatePost(e.target.value === '' ? '' : Number(e.target.value))}
                    className="w-full px-2.5 py-1.5 text-xs font-mono tabular-nums border border-slate-300 dark:border-slate-700 rounded-md bg-white dark:bg-slate-900 text-slate-900 dark:text-white"
                  />
                </div>
                <div className="p-3 bg-slate-50 dark:bg-slate-800/50 rounded-xl border border-slate-200 dark:border-slate-700">
                  <label className="block text-[11px] font-medium text-slate-600 dark:text-slate-400 mb-1">
                    Story Frame ($)
                  </label>
                  <input
                    type="number"
                    value={rateStory}
                    onChange={e => setRateStory(e.target.value === '' ? '' : Number(e.target.value))}
                    className="w-full px-2.5 py-1.5 text-xs font-mono tabular-nums border border-slate-300 dark:border-slate-700 rounded-md bg-white dark:bg-slate-900 text-slate-900 dark:text-white"
                  />
                </div>
              </div>

              <div className="space-y-3 pt-2">
                <label className="flex items-center gap-2.5 text-xs text-slate-700 dark:text-slate-300 cursor-pointer">
                  <input
                    type="checkbox"
                    checked={acceptRevShare}
                    onChange={e => setAcceptRevShare(e.target.checked)}
                    className="w-4 h-4 text-indigo-600 rounded border-slate-300 focus:ring-indigo-500"
                  />
                  <span>Open to Affiliate / Revenue Share bonus models alongside fixed fees</span>
                </label>
                <label className="flex items-center gap-2.5 text-xs text-slate-700 dark:text-slate-300 cursor-pointer">
                  <input
                    type="checkbox"
                    checked={acceptGifted}
                    onChange={e => setAcceptGifted(e.target.checked)}
                    className="w-4 h-4 text-indigo-600 rounded border-slate-300 focus:ring-indigo-500"
                  />
                  <span>Consider gifted product PR packages for authentic reviews</span>
                </label>
              </div>

              <div className="flex justify-between pt-6 border-t border-slate-100 dark:border-slate-800">
                <button
                  type="button"
                  onClick={() => setStep(3)}
                  className="px-4 py-2 border border-slate-300 dark:border-slate-700 text-slate-700 dark:text-slate-300 text-xs font-semibold rounded-lg hover:bg-slate-50"
                >
                  Back
                </button>
                <button
                  type="button"
                  onClick={handleFinish}
                  disabled={loading}
                  className="px-5 py-2.5 bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-semibold rounded-lg shadow-sm flex items-center gap-2 transition-colors disabled:opacity-50"
                >
                  {loading ? (
                    <span>Saving to Database...</span>
                  ) : (
                    <>
                      <span>Complete Onboarding & Enter Dashboard</span>
                      <Check className="w-4 h-4" />
                    </>
                  )}
                </button>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
