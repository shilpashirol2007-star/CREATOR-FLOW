import React, { useState, useEffect } from 'react';
import { useAuth } from '../context/AuthContext';
import { api } from '../lib/api';
import { Payment } from '../types';
import {
  DollarSign,
  FileText,
  Download,
  Plus,
  CheckCircle,
  Clock,
  ShieldCheck,
  CreditCard,
  Building,
  ArrowUpRight,
  X
} from 'lucide-react';

export const FinancePage: React.FC = () => {
  const { user } = useAuth();
  const isCreator = user?.role === 'creator';

  const [payments, setPayments] = useState<Payment[]>([]);
  const [loading, setLoading] = useState<boolean>(true);
  const [filter, setFilter] = useState<string>('all');

  // Invoice modal
  const [modalOpen, setModalOpen] = useState<boolean>(false);
  const [invAmount, setInvAmount] = useState<number | ''>('');
  const [invNotes, setInvNotes] = useState<string>('Sponsored media campaign deliverable fee');
  const [invMethod, setInvMethod] = useState<string>('Direct Wire / ACH');
  const [savingInv, setSavingInv] = useState(false);

  // View invoice receipt modal
  const [selectedInvoice, setSelectedInvoice] = useState<Payment | null>(null);

  const fetchPayments = async () => {
    try {
      setLoading(true);
      const res = await api.getPayments();
      setPayments(res);
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchPayments();
  }, []);

  const handleCreateInvoice = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!invAmount) return;
    setSavingInv(true);
    try {
      await api.createPayment({
        amount: Number(invAmount),
        paymentMethod: invMethod,
        notes: invNotes,
        creatorId: user?.id
      });
      setModalOpen(false);
      setInvAmount('');
      await fetchPayments();
    } catch (err: any) {
      alert(err.message || 'Invoice creation failed');
    } finally {
      setSavingInv(false);
    }
  };

  const totalEarned = payments
    .filter(p => p.status === 'released')
    .reduce((sum, p) => sum + Number(p.amount), 0);

  const inEscrow = payments
    .filter(p => p.status === 'in_escrow')
    .reduce((sum, p) => sum + Number(p.amount), 0);

  const pending = payments
    .filter(p => p.status === 'pending')
    .reduce((sum, p) => sum + Number(p.amount), 0);

  const filtered = payments.filter(p => {
    if (filter === 'all') return true;
    return p.status === filter;
  });

  return (
    <div className="p-6 md:p-8 max-w-7xl mx-auto space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-slate-200 dark:border-slate-800 pb-5">
        <div>
          <h1 className="text-xl md:text-2xl font-bold text-slate-900 dark:text-white">
            Finance, Escrow & Earnings
          </h1>
          <p className="text-xs text-slate-500 mt-1">
            {isCreator
              ? 'Track verified commercial payouts, monitor protected escrow balances, and generate tax invoices.'
              : 'Review sponsorship billing, manage escrow vault deposits, and disburse campaign creator fees.'}
          </p>
        </div>

        <button
          onClick={() => setModalOpen(true)}
          className="px-3.5 py-2 text-xs font-semibold text-white bg-indigo-600 hover:bg-indigo-700 rounded-lg shadow-xs flex items-center gap-1.5 transition-colors self-start sm:self-auto"
        >
          <Plus className="w-3.5 h-3.5" />
          <span>Generate Tax Invoice</span>
        </button>
      </div>

      {/* KPI Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
        <div className="p-5 bg-white dark:bg-slate-900 rounded-xl border border-slate-200 dark:border-slate-800 shadow-xs">
          <div className="flex items-center justify-between text-slate-500 mb-2">
            <span className="text-xs font-medium">{isCreator ? 'Total Paid Earnings' : 'Total Campaign Payouts'}</span>
            <DollarSign className="w-4 h-4 text-emerald-600" />
          </div>
          <div className="text-2xl font-bold font-mono tabular-nums text-slate-900 dark:text-white">
            ${totalEarned.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
          </div>
          <div className="text-[11px] text-emerald-600 mt-1">Directly cleared to bank account</div>
        </div>

        <div className="p-5 bg-white dark:bg-slate-900 rounded-xl border border-slate-200 dark:border-slate-800 shadow-xs">
          <div className="flex items-center justify-between text-slate-500 mb-2">
            <span className="text-xs font-medium">Secured in Escrow</span>
            <ShieldCheck className="w-4 h-4 text-indigo-600" />
          </div>
          <div className="text-2xl font-bold font-mono tabular-nums text-slate-900 dark:text-white">
            ${inEscrow.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
          </div>
          <div className="text-[11px] text-slate-500 mt-1">Locked until deliverable sign-off</div>
        </div>

        <div className="p-5 bg-white dark:bg-slate-900 rounded-xl border border-slate-200 dark:border-slate-800 shadow-xs">
          <div className="flex items-center justify-between text-slate-500 mb-2">
            <span className="text-xs font-medium">Pending Invoices</span>
            <Clock className="w-4 h-4 text-amber-500" />
          </div>
          <div className="text-2xl font-bold font-mono tabular-nums text-slate-900 dark:text-white">
            ${pending.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
          </div>
          <div className="text-[11px] text-slate-500 mt-1">Awaiting brand payment clearance</div>
        </div>
      </div>

      {/* Filter Tabs */}
      <div className="flex items-center gap-1.5 p-1 bg-slate-100 dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-lg max-w-sm">
        {[
          { id: 'all', label: 'All Transactions' },
          { id: 'released', label: 'Cleared' },
          { id: 'in_escrow', label: 'Escrow' },
          { id: 'pending', label: 'Pending' }
        ].map(tab => (
          <button
            key={tab.id}
            onClick={() => setFilter(tab.id)}
            className={`flex-1 py-1.5 text-xs font-semibold rounded-md transition-colors text-center ${
              filter === tab.id
                ? 'bg-white dark:bg-slate-800 text-slate-900 dark:text-white shadow-xs'
                : 'text-slate-600 dark:text-slate-400 hover:text-slate-900'
            }`}
          >
            {tab.label}
          </button>
        ))}
      </div>

      {/* Ledger Table */}
      <div className="bg-white dark:bg-slate-900 rounded-xl border border-slate-200 dark:border-slate-800 p-6 shadow-xs space-y-4">
        <h2 className="text-sm font-bold text-slate-900 dark:text-white">
          Payment Transactions & Invoices
        </h2>

        {filtered.length === 0 ? (
          <div className="p-8 text-center text-xs text-slate-500 border border-dashed border-slate-200 dark:border-slate-800 rounded-lg">
            No transaction records found matching this status filter.
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-xs text-left">
              <thead>
                <tr className="border-b border-slate-200 dark:border-slate-800 text-slate-500 font-semibold">
                  <th className="pb-2">Invoice #</th>
                  <th className="pb-2">Date</th>
                  <th className="pb-2">Description / Campaign</th>
                  <th className="pb-2">Method</th>
                  <th className="pb-2 text-right">Amount</th>
                  <th className="pb-2 text-center">Status</th>
                  <th className="pb-2 text-right">Action</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
                {filtered.map(p => (
                  <tr key={p.id} className="hover:bg-slate-50/50 dark:hover:bg-slate-800/30">
                    <td className="py-3 font-mono font-bold text-indigo-600 dark:text-indigo-400">
                      {p.invoiceNumber}
                    </td>
                    <td className="py-3 font-mono text-slate-500">{p.transactionDate}</td>
                    <td className="py-3 text-slate-800 dark:text-slate-200 font-medium">
                      {p.notes || p.campaignTitle || 'Commercial Deal'}
                    </td>
                    <td className="py-3 text-slate-500">{p.paymentMethod}</td>
                    <td className="py-3 text-right font-mono font-bold text-slate-900 dark:text-white tabular-nums">
                      ${Number(p.amount).toLocaleString('en-US', { minimumFractionDigits: 2 })}
                    </td>
                    <td className="py-3 text-center">
                      <span className={`px-2 py-0.5 rounded text-[10px] font-semibold uppercase ${
                        p.status === 'released'
                          ? 'bg-emerald-50 text-emerald-700 dark:bg-emerald-950/60 dark:text-emerald-300'
                          : p.status === 'in_escrow'
                          ? 'bg-indigo-50 text-indigo-700 dark:bg-indigo-950/60 dark:text-indigo-300'
                          : 'bg-amber-50 text-amber-700 dark:bg-amber-950/60 dark:text-amber-300'
                      }`}>
                        {p.status.replace('_', ' ')}
                      </span>
                    </td>
                    <td className="py-3 text-right">
                      <button
                        onClick={() => setSelectedInvoice(p)}
                        className="px-2.5 py-1 text-[11px] font-medium bg-slate-100 hover:bg-slate-200 dark:bg-slate-800 text-slate-700 dark:text-slate-300 rounded transition-colors"
                      >
                        Receipt
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>

      {/* Invoice Generator Modal */}
      {modalOpen && (
        <div className="fixed inset-0 bg-slate-900/50 backdrop-blur-xs flex items-center justify-center p-4 z-50">
          <div className="bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 max-w-md w-full p-6 shadow-xl">
            <div className="flex items-center justify-between pb-3 border-b border-slate-200 dark:border-slate-800">
              <h2 className="text-sm font-bold text-slate-900 dark:text-white">
                Generate Invoice
              </h2>
              <button onClick={() => setModalOpen(false)} className="text-slate-400 hover:text-slate-600">
                <X className="w-4 h-4" />
              </button>
            </div>

            <form onSubmit={handleCreateInvoice} className="mt-4 space-y-4">
              <div>
                <label className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1">
                  Invoice Amount ($ USD)
                </label>
                <input
                  type="number"
                  required
                  value={invAmount}
                  onChange={e => setInvAmount(Number(e.target.value))}
                  placeholder="e.g. 1250"
                  className="w-full px-3 py-2 text-xs font-mono tabular-nums border border-slate-300 dark:border-slate-700 rounded-lg bg-white dark:bg-slate-800 text-slate-900 dark:text-white outline-none"
                />
              </div>

              <div>
                <label className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1">
                  Payment Method / Channel
                </label>
                <select
                  value={invMethod}
                  onChange={e => setInvMethod(e.target.value)}
                  className="w-full px-3 py-2 text-xs border border-slate-300 dark:border-slate-700 rounded-lg bg-white dark:bg-slate-800 text-slate-900 dark:text-white outline-none"
                >
                  <option value="Direct Wire / ACH">Direct Wire / ACH Bank Transfer</option>
                  <option value="Stripe Connect">Stripe Connect Payout</option>
                  <option value="PayPal Commercial">PayPal Business</option>
                  <option value="Escrow Vault">CreatorFlow Escrow Vault</option>
                </select>
              </div>

              <div>
                <label className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1">
                  Description of Deliverables / Campaign
                </label>
                <textarea
                  rows={3}
                  value={invNotes}
                  onChange={e => setInvNotes(e.target.value)}
                  className="w-full px-3 py-2 text-xs border border-slate-300 dark:border-slate-700 rounded-lg bg-white dark:bg-slate-800 text-slate-900 dark:text-white outline-none"
                />
              </div>

              <div className="flex justify-end gap-2 pt-2">
                <button
                  type="button"
                  onClick={() => setModalOpen(false)}
                  className="px-3 py-1.5 text-xs text-slate-600 hover:text-slate-800"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={savingInv}
                  className="px-4 py-1.5 text-xs font-semibold bg-indigo-600 hover:bg-indigo-700 text-white rounded-lg shadow-xs"
                >
                  {savingInv ? 'Generating...' : 'Issue Invoice'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Invoice Receipt Modal */}
      {selectedInvoice && (
        <div className="fixed inset-0 bg-slate-900/50 backdrop-blur-xs flex items-center justify-center p-4 z-50">
          <div className="bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 max-w-lg w-full p-8 shadow-xl space-y-6">
            <div className="flex items-start justify-between border-b border-slate-200 dark:border-slate-800 pb-4">
              <div>
                <div className="text-xl font-bold text-slate-900 dark:text-white">CreatorFlow</div>
                <div className="text-xs text-slate-500 font-mono mt-0.5">Commercial Statement #{selectedInvoice.invoiceNumber}</div>
              </div>
              <button onClick={() => setSelectedInvoice(null)} className="text-slate-400 hover:text-slate-600">
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="grid grid-cols-2 gap-4 text-xs">
              <div>
                <div className="text-slate-400 text-[11px]">Issued To / Brand:</div>
                <div className="font-bold text-slate-900 dark:text-white">{selectedInvoice.brandName || 'Brand Partner'}</div>
              </div>
              <div>
                <div className="text-slate-400 text-[11px]">Payee / Creator:</div>
                <div className="font-bold text-slate-900 dark:text-white">{selectedInvoice.creatorName || user?.fullName}</div>
              </div>
              <div>
                <div className="text-slate-400 text-[11px]">Issue Date:</div>
                <div className="font-mono">{selectedInvoice.transactionDate}</div>
              </div>
              <div>
                <div className="text-slate-400 text-[11px]">Status:</div>
                <div className="font-bold uppercase text-emerald-600">{selectedInvoice.status}</div>
              </div>
            </div>

            <div className="p-4 bg-slate-50 dark:bg-slate-800/50 rounded-xl space-y-2">
              <div className="flex justify-between text-xs">
                <span>{selectedInvoice.notes || 'Deliverables Compensation'}</span>
                <span className="font-mono font-bold">${Number(selectedInvoice.amount).toFixed(2)}</span>
              </div>
              <div className="border-t border-slate-200 dark:border-slate-700 pt-2 flex justify-between text-sm font-bold">
                <span>Total Amount</span>
                <span className="font-mono">${Number(selectedInvoice.amount).toFixed(2)} USD</span>
              </div>
            </div>

            <div className="flex justify-between items-center pt-2">
              <button
                onClick={() => window.print()}
                className="px-3.5 py-1.5 text-xs font-semibold bg-slate-100 hover:bg-slate-200 dark:bg-slate-800 text-slate-700 dark:text-slate-200 rounded-lg flex items-center gap-1.5 transition-colors"
              >
                <Download className="w-3.5 h-3.5" />
                <span>Print / Save Statement</span>
              </button>
              <button
                onClick={() => setSelectedInvoice(null)}
                className="px-4 py-1.5 text-xs font-semibold bg-indigo-600 text-white rounded-lg"
              >
                Done
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
