import React, { useState, useEffect } from 'react';
import { useAuth } from '../context/AuthContext';
import { api } from '../lib/api';
import {
  Users,
  Briefcase,
  DollarSign,
  Video,
  ArrowUpRight,
  Youtube,
  Instagram,
  Plus,
  Clock,
  CheckCircle2,
  AlertCircle
} from 'lucide-react';

export const DashboardPage: React.FC<{ onNavigate: (tab: string) => void }> = ({ onNavigate }) => {
  const { user } = useAuth();
  const [data, setData] = useState<any>(null);
  const [loading, setLoading] = useState<boolean>(true);
  const [error, setError] = useState<string | null>(null);

  const fetchDashboard = async () => {
    try {
      setLoading(true);
      const res = await api.getDashboardSummary();
      setData(res);
    } catch (err: any) {
      setError(err.message || 'Failed to load dashboard metrics');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchDashboard();
  }, []);

  if (loading) {
    return (
      <div className="p-8 max-w-7xl mx-auto space-y-6 animate-pulse">
        <div className="h-8 bg-slate-200 dark:bg-slate-800 rounded-md w-1/4" />
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
          {[1, 2, 3, 4].map(i => (
            <div key={i} className="h-28 bg-slate-200 dark:bg-slate-800 rounded-xl" />
          ))}
        </div>
        <div className="h-64 bg-slate-200 dark:bg-slate-800 rounded-xl" />
      </div>
    );
  }

  const isCreator = user?.role === 'creator';
  const metrics = data?.metrics || {};

  return (
    <div className="p-6 md:p-8 max-w-7xl mx-auto space-y-8">
      {/* Welcome Banner */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-slate-200 dark:border-slate-800 pb-6">
        <div>
          <h1 className="text-xl md:text-2xl font-bold text-slate-900 dark:text-white">
            Welcome back, {user?.fullName}
          </h1>
          <p className="text-xs text-slate-500 mt-1">
            {isCreator
              ? 'Real-time overview of your verified audience, commercial deals, and upcoming deliverables.'
              : 'Enterprise portal for influencer campaigns, active rosters, and contract budgets.'}
          </p>
        </div>
        <div className="flex items-center gap-2">
          {isCreator ? (
            <>
              <button
                onClick={() => onNavigate('content')}
                className="px-3 py-1.5 text-xs font-semibold text-slate-700 dark:text-slate-200 bg-white dark:bg-slate-800 border border-slate-300 dark:border-slate-700 rounded-lg hover:bg-slate-50 transition-colors"
              >
                Schedule Content
              </button>
              <button
                onClick={() => onNavigate('collaborations')}
                className="px-3.5 py-1.5 text-xs font-semibold text-white bg-indigo-600 hover:bg-indigo-700 rounded-lg shadow-xs transition-colors flex items-center gap-1.5"
              >
                <span>View Brand Deals</span>
                <ArrowUpRight className="w-3.5 h-3.5" />
              </button>
            </>
          ) : (
            <>
              <button
                onClick={() => onNavigate('partnerships')}
                className="px-3 py-1.5 text-xs font-semibold text-slate-700 dark:text-slate-200 bg-white dark:bg-slate-800 border border-slate-300 dark:border-slate-700 rounded-lg hover:bg-slate-50 transition-colors"
              >
                Discover Creators
              </button>
              <button
                onClick={() => onNavigate('content')}
                className="px-3.5 py-1.5 text-xs font-semibold text-white bg-indigo-600 hover:bg-indigo-700 rounded-lg shadow-xs transition-colors"
              >
                Create Campaign
              </button>
            </>
          )}
        </div>
      </div>

      {/* Primary KPI Row - STRICTLY REAL DATABASE VALUES */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        {isCreator ? (
          <>
            {/* Total Followers */}
            <div className="p-5 bg-white dark:bg-slate-900 rounded-xl border border-slate-200 dark:border-slate-800 shadow-xs">
              <div className="flex items-center justify-between text-slate-500 mb-2">
                <span className="text-xs font-medium">Verified Audience</span>
                <Users className="w-4 h-4 text-slate-400" />
              </div>
              <div className="text-2xl font-bold text-slate-900 dark:text-white font-mono tabular-nums">
                {metrics.totalFollowers?.toLocaleString() || 0}
              </div>
              <div className="mt-2 text-[11px] text-slate-500 flex items-center gap-1.5">
                {metrics.socialAccountsCount > 0 ? (
                  <span className="text-emerald-600 font-medium">{metrics.socialAccountsCount} accounts connected</span>
                ) : (
                  <button
                    onClick={() => onNavigate('analytics')}
                    className="text-indigo-600 hover:underline font-medium"
                  >
                    Connect accounts
                  </button>
                )}
              </div>
            </div>

            {/* Active Brand Deals */}
            <div className="p-5 bg-white dark:bg-slate-900 rounded-xl border border-slate-200 dark:border-slate-800 shadow-xs">
              <div className="flex items-center justify-between text-slate-500 mb-2">
                <span className="text-xs font-medium">Active Collaborations</span>
                <Briefcase className="w-4 h-4 text-slate-400" />
              </div>
              <div className="text-2xl font-bold text-slate-900 dark:text-white font-mono tabular-nums">
                {metrics.activeCollabsCount || 0}
              </div>
              <div className="mt-2 text-[11px] text-slate-500">
                {metrics.activeCollabsCount > 0 ? 'Active contracts in progress' : 'No deals currently active'}
              </div>
            </div>

            {/* Total Earnings */}
            <div className="p-5 bg-white dark:bg-slate-900 rounded-xl border border-slate-200 dark:border-slate-800 shadow-xs">
              <div className="flex items-center justify-between text-slate-500 mb-2">
                <span className="text-xs font-medium">Verified Payouts</span>
                <DollarSign className="w-4 h-4 text-slate-400" />
              </div>
              <div className="text-2xl font-bold text-slate-900 dark:text-white font-mono tabular-nums">
                ${metrics.totalEarned?.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 }) || '0.00'}
              </div>
              <div className="mt-2 text-[11px] text-slate-500 font-mono tabular-nums">
                Pending Escrow: ${metrics.pendingPayout?.toLocaleString() || 0}
              </div>
            </div>

            {/* Content Pipeline */}
            <div className="p-5 bg-white dark:bg-slate-900 rounded-xl border border-slate-200 dark:border-slate-800 shadow-xs">
              <div className="flex items-center justify-between text-slate-500 mb-2">
                <span className="text-xs font-medium">Scheduled Content</span>
                <Video className="w-4 h-4 text-slate-400" />
              </div>
              <div className="text-2xl font-bold text-slate-900 dark:text-white font-mono tabular-nums">
                {metrics.scheduledPostsCount || 0}
              </div>
              <div className="mt-2 text-[11px] text-slate-500 font-mono tabular-nums">
                {metrics.publishedPostsCount || 0} posts published to date
              </div>
            </div>
          </>
        ) : (
          <>
            {/* Brand KPI cards */}
            <div className="p-5 bg-white dark:bg-slate-900 rounded-xl border border-slate-200 dark:border-slate-800 shadow-xs">
              <div className="flex items-center justify-between text-slate-500 mb-2">
                <span className="text-xs font-medium">Active Campaigns</span>
                <Briefcase className="w-4 h-4 text-slate-400" />
              </div>
              <div className="text-2xl font-bold text-slate-900 dark:text-white font-mono tabular-nums">
                {metrics.activeCampaignsCount || 0}
              </div>
              <div className="mt-2 text-[11px] text-slate-500">
                {metrics.totalCampaignsCount || 0} total campaigns created
              </div>
            </div>

            <div className="p-5 bg-white dark:bg-slate-900 rounded-xl border border-slate-200 dark:border-slate-800 shadow-xs">
              <div className="flex items-center justify-between text-slate-500 mb-2">
                <span className="text-xs font-medium">Allocated Budget</span>
                <DollarSign className="w-4 h-4 text-slate-400" />
              </div>
              <div className="text-2xl font-bold text-slate-900 dark:text-white font-mono tabular-nums">
                ${metrics.totalBudget?.toLocaleString() || 0}
              </div>
              <div className="mt-2 text-[11px] text-slate-500">Committed campaign funds</div>
            </div>

            <div className="p-5 bg-white dark:bg-slate-900 rounded-xl border border-slate-200 dark:border-slate-800 shadow-xs">
              <div className="flex items-center justify-between text-slate-500 mb-2">
                <span className="text-xs font-medium">Active Creators</span>
                <Users className="w-4 h-4 text-slate-400" />
              </div>
              <div className="text-2xl font-bold text-slate-900 dark:text-white font-mono tabular-nums">
                {metrics.activeCollabsCount || 0}
              </div>
              <div className="mt-2 text-[11px] text-slate-500">Contracts in active production</div>
            </div>

            <div className="p-5 bg-white dark:bg-slate-900 rounded-xl border border-slate-200 dark:border-slate-800 shadow-xs">
              <div className="flex items-center justify-between text-slate-500 mb-2">
                <span className="text-xs font-medium">Funds in Escrow</span>
                <DollarSign className="w-4 h-4 text-slate-400" />
              </div>
              <div className="text-2xl font-bold text-slate-900 dark:text-white font-mono tabular-nums">
                ${metrics.inEscrow?.toLocaleString() || 0}
              </div>
              <div className="mt-2 text-[11px] text-slate-500">Protected until delivery approval</div>
            </div>
          </>
        )}
      </div>

      {/* Grid: Connected Accounts & Pipeline */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Left Column: Channels / Pipeline */}
        <div className="lg:col-span-2 space-y-6">
          {/* Social Channels Section */}
          <div className="bg-white dark:bg-slate-900 rounded-xl border border-slate-200 dark:border-slate-800 p-6 shadow-xs">
            <div className="flex items-center justify-between mb-4">
              <div>
                <h2 className="text-sm font-bold text-slate-900 dark:text-white">
                  Connected Channel Network
                </h2>
                <p className="text-xs text-slate-500">Directly synchronized platform metrics</p>
              </div>
              <button
                onClick={() => onNavigate('analytics')}
                className="text-xs font-semibold text-indigo-600 hover:text-indigo-700 flex items-center gap-1"
              >
                <span>Manage Channels</span>
                <ArrowUpRight className="w-3.5 h-3.5" />
              </button>
            </div>

            {data?.socialAccounts && data.socialAccounts.length > 0 ? (
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                {data.socialAccounts.map((account: any) => (
                  <div
                    key={account.id}
                    className="p-4 rounded-lg border border-slate-200 dark:border-slate-800 bg-slate-50/50 dark:bg-slate-800/40 flex items-center justify-between"
                  >
                    <div className="flex items-center gap-3">
                      {account.platform === 'youtube' && <Youtube className="w-6 h-6 text-red-600 shrink-0" />}
                      {account.platform === 'instagram' && <Instagram className="w-6 h-6 text-pink-600 shrink-0" />}
                      {account.platform !== 'youtube' && account.platform !== 'instagram' && (
                        <div className="w-6 h-6 rounded bg-slate-200 dark:bg-slate-700 flex items-center justify-center font-bold text-xs uppercase">
                          {account.platform.charAt(0)}
                        </div>
                      )}
                      <div>
                        <div className="text-xs font-bold text-slate-900 dark:text-white">
                          {account.handle}
                        </div>
                        <div className="text-[11px] text-slate-500">
                          {account.apiStatus === 'connected' ? 'Verified API Sync' : 'Verified Manual'}
                        </div>
                      </div>
                    </div>
                    <div className="text-right">
                      <div className="text-xs font-bold font-mono tabular-nums text-slate-900 dark:text-white">
                        {Number(account.followerCount || 0).toLocaleString()}
                      </div>
                      <div className="text-[11px] text-slate-500">
                        {account.engagementRate ? `${account.engagementRate}% ER` : 'Followers'}
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            ) : (
              <div className="p-8 text-center border border-dashed border-slate-200 dark:border-slate-800 rounded-lg">
                <p className="text-xs text-slate-500">No social media accounts connected yet.</p>
                <button
                  onClick={() => onNavigate('analytics')}
                  className="mt-3 inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold text-indigo-600 bg-indigo-50 dark:bg-indigo-950/40 rounded-lg hover:bg-indigo-100 transition-colors"
                >
                  <Plus className="w-3.5 h-3.5" />
                  <span>Connect YouTube or Instagram</span>
                </button>
              </div>
            )}
          </div>

          {/* Active Collaborations List */}
          <div className="bg-white dark:bg-slate-900 rounded-xl border border-slate-200 dark:border-slate-800 p-6 shadow-xs">
            <div className="flex items-center justify-between mb-4">
              <div>
                <h2 className="text-sm font-bold text-slate-900 dark:text-white">
                  Active Brand Collaborations
                </h2>
                <p className="text-xs text-slate-500">Recent commercial contracts & deliverables</p>
              </div>
              <button
                onClick={() => onNavigate('collaborations')}
                className="text-xs font-semibold text-indigo-600 hover:text-indigo-700 flex items-center gap-1"
              >
                <span>View All Deals</span>
                <ArrowUpRight className="w-3.5 h-3.5" />
              </button>
            </div>

            {data?.activeCollabs && data.activeCollabs.length > 0 ? (
              <div className="space-y-3">
                {data.activeCollabs.map((collab: any) => (
                  <div
                    key={collab.id}
                    className="p-3.5 rounded-lg border border-slate-200 dark:border-slate-800 hover:border-slate-300 flex flex-col sm:flex-row sm:items-center justify-between gap-3 transition-colors"
                  >
                    <div>
                      <div className="text-xs font-bold text-slate-900 dark:text-white flex items-center gap-2">
                        <span>{collab.campaignTitle || 'Brand Partnership'}</span>
                        <span className="text-[11px] font-normal text-slate-500">with {isCreator ? collab.brandName : collab.creatorName}</span>
                      </div>
                      <div className="text-[11px] text-slate-500 mt-0.5">
                        Status: <span className="font-semibold capitalize text-slate-700 dark:text-slate-300">{collab.status}</span> · Deliverables: {collab.deliverables?.length || 0}
                      </div>
                    </div>
                    <div className="flex items-center gap-4">
                      <span className="text-xs font-bold font-mono tabular-nums text-slate-900 dark:text-white">
                        ${collab.agreedAmount || collab.offeredAmount}
                      </span>
                      <button
                        onClick={() => onNavigate('collaborations')}
                        className="px-2.5 py-1 text-[11px] font-medium bg-slate-100 hover:bg-slate-200 dark:bg-slate-800 text-slate-700 dark:text-slate-300 rounded"
                      >
                        Manage
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            ) : (
              <div className="p-8 text-center border border-dashed border-slate-200 dark:border-slate-800 rounded-lg">
                <p className="text-xs text-slate-500">No active collaborations in progress.</p>
                <button
                  onClick={() => onNavigate('partnerships')}
                  className="mt-3 inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold text-indigo-600 bg-indigo-50 dark:bg-indigo-950/40 rounded-lg hover:bg-indigo-100 transition-colors"
                >
                  <span>{isCreator ? 'Browse Campaign Opportunities' : 'Recruit Creators'}</span>
                  <ArrowUpRight className="w-3.5 h-3.5" />
                </button>
              </div>
            )}
          </div>
        </div>

        {/* Right Column: Deadlines & Notifications */}
        <div className="space-y-6">
          {/* Upcoming Schedule */}
          <div className="bg-white dark:bg-slate-900 rounded-xl border border-slate-200 dark:border-slate-800 p-6 shadow-xs">
            <div className="flex items-center justify-between mb-4">
              <h2 className="text-sm font-bold text-slate-900 dark:text-white">
                Upcoming Deadlines
              </h2>
              <button
                onClick={() => onNavigate('calendar')}
                className="text-xs text-indigo-600 hover:underline font-medium"
              >
                Calendar
              </button>
            </div>

            {data?.upcomingEvents && data.upcomingEvents.length > 0 ? (
              <div className="space-y-2.5">
                {data.upcomingEvents.map((evt: any) => (
                  <div key={evt.id} className="p-2.5 bg-slate-50 dark:bg-slate-800/40 rounded-lg border border-slate-200 dark:border-slate-800">
                    <div className="text-xs font-semibold text-slate-900 dark:text-white truncate">
                      {evt.title}
                    </div>
                    <div className="text-[11px] text-slate-500 flex items-center gap-1 mt-0.5">
                      <Clock className="w-3 h-3" />
                      <span className="font-mono">{evt.date}</span>
                    </div>
                  </div>
                ))}
              </div>
            ) : (
              <div className="p-6 text-center text-xs text-slate-500 border border-dashed border-slate-200 dark:border-slate-800 rounded-lg">
                No upcoming deadlines on schedule.
              </div>
            )}
          </div>

          {/* Recent Activity */}
          <div className="bg-white dark:bg-slate-900 rounded-xl border border-slate-200 dark:border-slate-800 p-6 shadow-xs">
            <div className="flex items-center justify-between mb-4">
              <h2 className="text-sm font-bold text-slate-900 dark:text-white">
                Activity Feed
              </h2>
              <button
                onClick={() => onNavigate('notifications')}
                className="text-xs text-indigo-600 hover:underline font-medium"
              >
                View All
              </button>
            </div>

            {data?.recentNotifications && data.recentNotifications.length > 0 ? (
              <div className="space-y-2.5">
                {data.recentNotifications.map((note: any) => (
                  <div key={note.id} className="text-xs border-b border-slate-100 dark:border-slate-800 pb-2 last:border-0 last:pb-0">
                    <div className="font-semibold text-slate-900 dark:text-white">
                      {note.title}
                    </div>
                    <div className="text-slate-500 text-[11px] mt-0.5 line-clamp-2">
                      {note.message}
                    </div>
                  </div>
                ))}
              </div>
            ) : (
              <div className="p-6 text-center text-xs text-slate-500 border border-dashed border-slate-200 dark:border-slate-800 rounded-lg">
                No recent activity recorded.
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};
