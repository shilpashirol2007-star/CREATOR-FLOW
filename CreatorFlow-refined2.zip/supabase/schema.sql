-- ====================================================================
-- CREATORFLOW SUPABASE SCHEMA
-- Production database tables, relationships, indexes, and RLS policies
-- ====================================================================

-- 1. Enable UUID Extension
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";

-- 2. USERS TABLE
CREATE TABLE IF NOT EXISTS public.users (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  email TEXT UNIQUE NOT NULL,
  password_hash TEXT NOT NULL,
  role TEXT NOT NULL CHECK (role IN ('creator', 'brand')),
  full_name TEXT NOT NULL,
  avatar_url TEXT,
  phone TEXT,
  onboarded BOOLEAN DEFAULT FALSE,
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- 3. CREATOR PROFILES TABLE
CREATE TABLE IF NOT EXISTS public.creator_profiles (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  user_id UUID NOT NULL REFERENCES public.users(id) ON DELETE CASCADE UNIQUE,
  bio TEXT DEFAULT '',
  niche TEXT NOT NULL DEFAULT 'Lifestyle',
  location TEXT DEFAULT '',
  website TEXT,
  primary_platform TEXT DEFAULT 'youtube' CHECK (primary_platform IN ('youtube', 'instagram', 'tiktok', 'twitter', 'other')),
  content_categories JSONB DEFAULT '[]'::jsonb,
  rate_post NUMERIC DEFAULT 0,
  rate_video NUMERIC DEFAULT 0,
  rate_reel NUMERIC DEFAULT 0,
  rate_story NUMERIC DEFAULT 0,
  accept_gifted BOOLEAN DEFAULT FALSE,
  accept_rev_share BOOLEAN DEFAULT FALSE,
  media_kit_url TEXT,
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- 4. BRAND PROFILES TABLE
CREATE TABLE IF NOT EXISTS public.brand_profiles (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  user_id UUID NOT NULL REFERENCES public.users(id) ON DELETE CASCADE UNIQUE,
  company_name TEXT NOT NULL,
  industry TEXT NOT NULL DEFAULT 'E-commerce',
  website TEXT,
  logo_url TEXT,
  contact_person TEXT NOT NULL,
  budget_tier TEXT DEFAULT 'growth',
  description TEXT DEFAULT '',
  target_audience TEXT DEFAULT '',
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- 5. SOCIAL ACCOUNTS TABLE
CREATE TABLE IF NOT EXISTS public.social_accounts (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  user_id UUID NOT NULL REFERENCES public.users(id) ON DELETE CASCADE,
  platform TEXT NOT NULL CHECK (platform IN ('youtube', 'instagram', 'tiktok', 'twitter')),
  handle TEXT NOT NULL,
  display_name TEXT NOT NULL,
  profile_image TEXT,
  follower_count INTEGER DEFAULT 0,
  subscribers INTEGER DEFAULT 0,
  total_views BIGINT DEFAULT 0,
  engagement_rate NUMERIC(5,2) DEFAULT 0.00,
  is_verified_api BOOLEAN DEFAULT FALSE,
  api_status TEXT DEFAULT 'unconnected' CHECK (api_status IN ('connected', 'manual', 'unconnected')),
  last_synced_at TIMESTAMPTZ,
  created_at TIMESTAMPTZ DEFAULT NOW(),
  UNIQUE(user_id, platform)
);

-- 6. CONTENT POSTS TABLE
CREATE TABLE IF NOT EXISTS public.content_posts (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  user_id UUID NOT NULL REFERENCES public.users(id) ON DELETE CASCADE,
  title TEXT NOT NULL,
  platform TEXT NOT NULL CHECK (platform IN ('youtube', 'instagram', 'tiktok', 'twitter')),
  content_type TEXT NOT NULL CHECK (content_type IN ('video', 'reel', 'short', 'post', 'story', 'carousel')),
  status TEXT NOT NULL DEFAULT 'idea' CHECK (status IN ('idea', 'scripting', 'in_review', 'scheduled', 'published')),
  scheduled_for TIMESTAMPTZ,
  published_at TIMESTAMPTZ,
  post_url TEXT,
  caption TEXT,
  deliverables_notes TEXT,
  campaign_id UUID,
  views INTEGER DEFAULT 0,
  likes INTEGER DEFAULT 0,
  comments INTEGER DEFAULT 0,
  shares INTEGER DEFAULT 0,
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- 7. CAMPAIGNS TABLE (Managed by Brands)
CREATE TABLE IF NOT EXISTS public.campaigns (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  brand_id UUID NOT NULL REFERENCES public.users(id) ON DELETE CASCADE,
  title TEXT NOT NULL,
  description TEXT NOT NULL,
  budget NUMERIC NOT NULL DEFAULT 0,
  compensation_type TEXT DEFAULT 'fixed' CHECK (compensation_type IN ('fixed', 'rev_share', 'gifted', 'hybrid')),
  category TEXT NOT NULL,
  requirements TEXT NOT NULL,
  deadline DATE NOT NULL,
  status TEXT NOT NULL DEFAULT 'active' CHECK (status IN ('draft', 'active', 'in_progress', 'completed', 'paused')),
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- 8. COLLABORATIONS TABLE (Two-way workflow between Brand & Creator)
CREATE TABLE IF NOT EXISTS public.collaborations (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  campaign_id UUID REFERENCES public.campaigns(id) ON DELETE SET NULL,
  brand_id UUID NOT NULL REFERENCES public.users(id) ON DELETE CASCADE,
  creator_id UUID NOT NULL REFERENCES public.users(id) ON DELETE CASCADE,
  status TEXT NOT NULL DEFAULT 'requested' CHECK (status IN ('requested', 'negotiating', 'accepted', 'rejected', 'in_progress', 'completed', 'cancelled')),
  offered_amount NUMERIC NOT NULL DEFAULT 0,
  agreed_amount NUMERIC NOT NULL DEFAULT 0,
  terms TEXT NOT NULL,
  deliverables JSONB DEFAULT '[]'::jsonb,
  creator_notes TEXT,
  brand_notes TEXT,
  payment_status TEXT DEFAULT 'unpaid' CHECK (payment_status IN ('unpaid', 'in_escrow', 'released', 'refunded')),
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- 9. CALENDAR EVENTS TABLE
CREATE TABLE IF NOT EXISTS public.calendar_events (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  user_id UUID NOT NULL REFERENCES public.users(id) ON DELETE CASCADE,
  title TEXT NOT NULL,
  description TEXT,
  event_type TEXT NOT NULL CHECK (event_type IN ('post_publish', 'deliverable_deadline', 'brand_meeting', 'campaign_launch')),
  date DATE NOT NULL,
  end_date DATE,
  all_day BOOLEAN DEFAULT TRUE,
  related_id UUID,
  status TEXT DEFAULT 'scheduled',
  created_at TIMESTAMPTZ DEFAULT NOW()
);

-- 10. ANALYTICS TABLE
CREATE TABLE IF NOT EXISTS public.analytics (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  user_id UUID NOT NULL REFERENCES public.users(id) ON DELETE CASCADE,
  platform TEXT NOT NULL CHECK (platform IN ('youtube', 'instagram', 'tiktok', 'twitter')),
  recorded_date DATE NOT NULL,
  followers INTEGER DEFAULT 0,
  impressions INTEGER DEFAULT 0,
  reach INTEGER DEFAULT 0,
  views INTEGER DEFAULT 0,
  engagement_rate NUMERIC(5,2) DEFAULT 0.00,
  shares INTEGER DEFAULT 0,
  comments INTEGER DEFAULT 0,
  source TEXT DEFAULT 'manual' CHECK (source IN ('api', 'manual')),
  created_at TIMESTAMPTZ DEFAULT NOW()
);

-- 11. PAYMENTS TABLE
CREATE TABLE IF NOT EXISTS public.payments (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  collaboration_id UUID REFERENCES public.collaborations(id) ON DELETE SET NULL,
  creator_id UUID NOT NULL REFERENCES public.users(id) ON DELETE CASCADE,
  brand_id UUID NOT NULL REFERENCES public.users(id) ON DELETE CASCADE,
  amount NUMERIC NOT NULL,
  currency TEXT DEFAULT 'USD',
  status TEXT NOT NULL DEFAULT 'pending' CHECK (status IN ('pending', 'in_escrow', 'released', 'failed')),
  invoice_number TEXT UNIQUE NOT NULL,
  payment_method TEXT DEFAULT 'bank_transfer',
  transaction_date DATE NOT NULL,
  notes TEXT,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

-- 12. NOTIFICATIONS TABLE
CREATE TABLE IF NOT EXISTS public.notifications (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  user_id UUID NOT NULL REFERENCES public.users(id) ON DELETE CASCADE,
  title TEXT NOT NULL,
  message TEXT NOT NULL,
  type TEXT NOT NULL CHECK (type IN ('collab_offer', 'status_update', 'payment', 'deadline', 'system')),
  read BOOLEAN DEFAULT FALSE,
  link TEXT,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

-- ====================================================================
-- ROW LEVEL SECURITY (RLS) POLICIES
-- ====================================================================
ALTER TABLE public.users ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.creator_profiles ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.brand_profiles ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.social_accounts ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.content_posts ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.campaigns ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.collaborations ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.calendar_events ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.analytics ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.payments ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.notifications ENABLE ROW LEVEL SECURITY;

-- Users can read their own profile
CREATE POLICY "Users read own profile" ON public.users
  FOR SELECT USING (auth.uid() = id);

-- Public can view creator profiles for discovery
CREATE POLICY "Public read creator profiles" ON public.creator_profiles
  FOR SELECT USING (true);

-- Creators manage their own profile
CREATE POLICY "Creators modify own profile" ON public.creator_profiles
  FOR ALL USING (auth.uid() = user_id);

-- Brand profiles
CREATE POLICY "Public read brand profiles" ON public.brand_profiles
  FOR SELECT USING (true);
CREATE POLICY "Brands modify own profile" ON public.brand_profiles
  FOR ALL USING (auth.uid() = user_id);

-- Social Accounts: Public can view for stats, creators can manage own
CREATE POLICY "Public read social accounts" ON public.social_accounts
  FOR SELECT USING (true);
CREATE POLICY "Users modify own social accounts" ON public.social_accounts
  FOR ALL USING (auth.uid() = user_id);

-- Content Posts: Creators manage own posts
CREATE POLICY "Users view own content posts" ON public.content_posts
  FOR ALL USING (auth.uid() = user_id);

-- Campaigns: Brands manage their campaigns, Creators can read active
CREATE POLICY "Brands manage campaigns" ON public.campaigns
  FOR ALL USING (auth.uid() = brand_id);
CREATE POLICY "Creators view active campaigns" ON public.campaigns
  FOR SELECT USING (status = 'active');

-- Collaborations: Visible and manageable only by involved creator or brand
CREATE POLICY "Parties manage collaborations" ON public.collaborations
  FOR ALL USING (auth.uid() = creator_id OR auth.uid() = brand_id);

-- Calendar: User specific
CREATE POLICY "Users manage calendar events" ON public.calendar_events
  FOR ALL USING (auth.uid() = user_id);

-- Analytics: User specific
CREATE POLICY "Users manage analytics" ON public.analytics
  FOR ALL USING (auth.uid() = user_id);

-- Payments: Parties involved can view
CREATE POLICY "Parties view payments" ON public.payments
  FOR SELECT USING (auth.uid() = creator_id OR auth.uid() = brand_id);

-- Notifications: User specific
CREATE POLICY "Users manage notifications" ON public.notifications
  FOR ALL USING (auth.uid() = user_id);
