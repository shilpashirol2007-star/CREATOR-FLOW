# CreatorFlow — Creator & Brand Collaboration Platform

CreatorFlow is a React + Vite frontend served by an Express API. **Deploy it as a Node web service.** GitHub stores the source code, but GitHub Pages cannot run the Express API or persist the local JSON database.

## Requirements
- Node.js 20.19+ (Node 22 recommended)
- npm
- Optional Supabase project for remote database integration

## Run locally
```bash
npm install
cp .env.example .env
npm run dev
```
Open the local URL printed by the server (normally http://localhost:3000).

## Deploy from GitHub using Render
1. Push the complete project folder to a GitHub repository.
2. In Render, choose **New → Blueprint** and connect the repository.
3. Render detects `render.yaml` and creates the Node web service.
4. Wait for deployment, then open the Render service URL.
5. Check `https://YOUR-SERVICE.onrender.com/api/health`; it should return JSON with `status: \"ok\"`.

The included persistent disk preserves the local JSON database across restarts. A persistent disk requires a paid Render plan. For production teams and multi-instance scaling, configure Supabase and use a database-backed implementation rather than relying on local JSON storage.

## Environment variables
See `.env.example`. Set secrets in the hosting provider's environment-variable settings; do not commit `.env` or service-role keys to GitHub.
- `SUPABASE_URL`
- `SUPABASE_ANON_KEY`
- `SUPABASE_SERVICE_ROLE_KEY` (server-side only; never expose in browser code)
- `GEMINI_API_KEY` (only if an enabled server feature requires Gemini)

## GitHub Pages warning
Do not select GitHub Pages for this project in its current architecture. Pages hosts static files only, while CreatorFlow calls `/api/*` for login, profiles, content, collaborations and other data. Static-only deployment cannot provide those API functions.

## Build and run production
```bash
npm run build
npm start
```
The production server serves `dist` and the Express `/api/*` endpoints from the same origin.
